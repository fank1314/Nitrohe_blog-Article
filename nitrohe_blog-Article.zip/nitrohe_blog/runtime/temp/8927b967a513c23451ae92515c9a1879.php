<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"D:\wamp\www\nitrohe_blog/application/admin\view\index\commentManagement.html";i:1538127531;s:67:"D:\wamp\www\nitrohe_blog\application\admin\view\baseView\index.html";i:1543641067;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        
<title>评论管理</title>
<div class="comment-Mg">
    <p>评论管理</p>
    <div>
        <input type="checkbox" id="sel-comms" style="position: relative;top: 10px;">
        <select class="selectpicker" id="com-op-sel" title="批量操作">
            <option name="del" value="1">删除</option>
        </select>
        <button class="btn" id="apply-op">应用</button>
    </div>
    <div class="commmg-table">
        <table class="table table-hover commmg-list">
            <tr>
                <th>文章标题</th>
                <th>评论用户</th>
                <th>评论内容</th>
                <th>回复至</th>
                <th class="art-date">评论日期<span>
                    <a style="color: #5bc0de"><i class="iconfont">&#xe655;</i></a>
                </span></th>
                <th>操作</th>
            </tr>
            <?php if(is_array($comment) || $comment instanceof \think\Collection || $comment instanceof \think\Paginator): if( count($comment)==0 ) : echo "" ;else: foreach($comment as $key=>$comm): ?>
            <tr>
                <td style="width: 10%"><span class="comm-arttitle"><?php echo $comm['comment_title']; ?></span></td>
                <td style="width: 15%">
                    <div class="td-comm-user">
                        <span class="comm-name">
                        <?php echo $comm['comment_user']; ?>
                        </span><span>
                        qq:<?php echo $comm['comment_qq']; ?>
                        </span>
                    </div>
                </td>
                <td style="width: 30%"><?php echo $comm['comment_content']; ?></td>
                <td><a class="comm-reply"><span class="parent_comm"><?php echo $comm['comment_parents']; ?></span></a></td>
                <td><?php echo $comm['comment_date']; ?></td>
                <td class="td-btn">
                    <button class="btn reply">回复</button>
                    <button class="btn del">删除</button>
                </td>

                <td style="display:none;" class="comm-id"><?php echo $comm['comment_id']; ?></td>
                <td style="display:none;" class="comm-parent"><?php echo $comm['comment_parent']; ?></td>
                <td style="display:none;" class="comm-artid"><?php echo $comm['article_id']; ?></td>
            </tr>

            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <div class="page">
            <?php echo $page; ?>

        </div>
    </div>


</div>
<script>
    var $comment_input = '        <tr class="tr-comm-input"  style="height: 200px" >\n' +
        '                    <td colspan="6" >\n' +
        '                        <div class="comment-input" >\n' +
        '                            <div style="display: none">\n' +
        '                                <div><span></span></div>\n' +
        '                            </div>\n' +
        '                            <div>\n' +
        '                                        <textarea class="comm-content"  rows="5" cols="80">\n' +
        '\n' +
        '                                       </textarea>\n' +
        '                            </div>\n' +
        '                            <div class="comment-user" style="width: 100%">\n' +
        '\n' +
        '                                <div>\n' +
        '                                    <button class="btn comment-btn">提交评论</button>\n' +
        '                                </div>\n' +
        '                            </div>\n' +
        '\n' +
        '                        </div>\n' +
        '                    </td>\n' +
        '                </tr>\n' +
        '                ';
    comment_input = $.parseHTML($comment_input);
    $('.commmg-list').on('click', '.reply', function () {
        console.log($(this).parent().next().attr('class'))
        if ($(this).parent().parent().next().attr('class') != 'tr-comm-input') {
            $(this).parent().parent().after(comment_input);
        } else {
            $(this).parent().parent().next().remove();

        }
    })


    $('.commmg-list').on('click', '.comment-btn', function () {
        var commid = <?php echo $commlastid; ?> + 1;
        var artId = $(this).parent().parent().parent().parent().parent().prev().find('.comm-artid').text();
        var commentext = $(this).parent().parent().parent().find('textarea').val();
        var username = '作者:';
        var qq = '0000000';
        var curtime = formatDate(new Date().getTime());
        var addcom = null;
        var info = null;
        var replyId = $(this).parent().parent().parent().parent().parent().prev().find('.comm-id').text();
        var index = null;
        var commthis = null;
        var arttitle = $(this).parent().parent().parent().parent().parent().prev().find('.comm-arttitle').text();
        var parentcomm = $(this).parent().parent().parent().parent().parent().prev().find('.parent_comm').text();
        var headImgUrl = "/nitrohe_blog/public/static/headimg/" + Math.ceil(Math.random() * 10) + ".jpg";
        info = ' <tr>\n' +
            '                <td>' + arttitle + '</td>\n' +
            '                <td>\n' +
            '                    <div>\n' +
            '                        <span class="comm-name">\n' +
            username +
            '                        </span><span>qq:' +
            qq +
            '</span>\n' +
            '                    </div>\n' +
            '                </td>\n' +
            '                <td>' + commentext + '</td>\n' +
            '                 <td><a class="comm-reply"><span class="parent_comm">'+parentcomm+'</span></a></td>\n' +
            '                <td>' + curtime + '</td>\n' +
            '                <td>\n' +
            '                        <button class="btn reply">回复</button>\n' +
            '                        <button class="btn del">删除</button>\n' +
            '                </td>\n' +
            '                <td style="display:none;" class="comm-id">' + commid + '</td>\n' +
            '                <td style="display:none;" class="comm-parent">'+replyId+'</td>\n' +
            '                <td style="display:none;" class="comm-artid">' + artId + '</td>\n' +
            '            </tr>';
        // console.log(replyId);
        commthis = addcom = $(this).parent().parent().parent().parent().parent();
        commid++;
        commAjax({
            'data': JSON.stringify({
                commenttext: commentext,
                username: username,
                qq: qq,
                artId: artId,
                comment_parent: replyId,
                headimgUrl: headImgUrl
            })
        }, addcom, info, commthis);

    });

    function commAjax(data, addcom, info, commthis) {
        $.ajax({
            type: 'post',
            data: data,
            dataType: 'json',
            url: "<?php echo Url('index/index/addComment'); ?>",
            success: function (data) {
                console.log("com" + JSON.stringify(data));

                var html = $.parseHTML(info);
                addcom.after(html);
                alert_success('提示', '回复成功');
                setTimeout(function () {
                    $('.comm-content').val('');
                    $('.qq').val('');
                    $('.username').val('');
                    commthis.remove();
                }, 3000);
            },
            error: function () {
                alert_fail('提示', '未知错误')
            }


        });

    }

    $('.commmg-list').on('click', '.del', function () {
        var commid = $(this).parent().next().text();
        alert_ask('确定要删除此评论(所有回复评论也将会全部删除)?', function () {
            $.ajax({
                type: 'post',
                dataType: 'json',
                data: {'data': JSON.stringify({commid: commid})},
                url: '<?php echo Url("admin/index/delComment"); ?>',
                success: function (data) {
                    console.log(data);
                    var url = window.location.href;
                    alert_success_url('提示', '删除成功', url);
                },
                error: function () {
                    alert_fail('提示', '未知错误')
                }
            })
        })


    });
    $('th.art-date>span').click(function () {
        var Request = new Object();
        Request = GetRequest();
        if (Request['artid'] === undefined || Request['artid'] == null) {
            Request['artid'] = -1;
        }
        if (Request['page'] === undefined) {
            Request['page'] = 1;
        }
        if (Request['dateOrder'] !== 2) {
            window.location.href = "<?php echo Url('admin/index/commentManagement'); ?>?artid=" + Request['artid'] + "&dateOrder=" + 2 + "&page=" + Request['page']+ "&reply=" + reply;
        } else {
            window.location.href = "<?php echo Url('admin/index/commentManagement'); ?>?artid=" + Request['artid'] + "dateOrder=" + 1 + "&page=" + Request['page']+ "&reply=" + reply;

        }
    });
    $('#sel-comms').click(function () {
        if ($(this).is(':checked')) {
            $('.commmg-list tr:first-child>th:first-child').before('<th><input type="checkbox" class="sel-all"><span>全选</span></th>');

            $('.commmg-list tr').each(function (index) {
                var commid = $(this).find('.comm-id').text();
                $(this).find('td:first-child').before('<td><input type="checkbox"  class="sel-comm-check" value=' + commid + '></td>');
            });
            $('.commmg-list').on('click', '.sel-all', function () {
                if ($(this).is(':checked')) {
                    $('.sel-comm-check').prop('checked', 'checked');
                    $('table tr:first-child th:first-child span').html('取消全选');
                } else {
                    $('.sel-comm-check').removeAttr('checked');
                    $('table tr:first-child th:first-child span').html('全选');

                }
            });
            $('.commmg-list tr>td:first-child').css('width', '8%');
        } else {
            $('.commmg-list tr:first-child>th:first-child').remove();

            $('.commmg-list tr').each(function (index) {
                $(this).find('td:first-child').remove();
            });
        }
    });

    $('#apply-op').click(function () {
        var selval = $('#com-op-sel').val();
        // console.log(selval)
        var commids = new Array();
        if (selval == undefined || selval == '') {
            alert_fail('提示', '未选择操作')
        } else {
            $('.sel-comm-check:checked').each(function (index, ele) {
                // console.log($(this).val())
                commids[index] = $(this).val();
            })
            // console.log(commids);
            if (commids.length == 0) {
                alert_fail('提示', '你未选择评论')
            } else {
                if (selval == 1) {
                    selOp("<?php echo Url('admin/index/delComment'); ?>", commids);
                }


            }
        }
    });

    function selOp(url, commids) {
        for (var i = 0; i < commids.length; i++) {
            ajaxs({'data': JSON.stringify({commid: commids[i]})}, url, function () {
                alert_success('提示', '操作成功')
            })
        }
        setTimeout(function () {
            $('.sel-comm-check:checked').each(function (index, ele) {
                // console.log($(this).val())
                $(this).parent().parent().remove()
            })
        }, 2000)
    }

    function ajaxs(data, url, succ) {
        var re = 0;
        $.ajax({
            type: 'post',
            data: data,
            dataType: 'json',
            url: url,
            success: function (data) {
                console.log(data)
                if (JSON.stringify(data) == '1') {
                    succ();
                } else {
                    alert_fail('提示', '操作失败')

                }
            }
            , error: function () {
                alert_fail('提示', '未知错误')
            }

        })
    }

    $('.commmg-list').on('click','.comm-reply',function () {
        Request = new Object();
        Request = GetRequest();
        var reply = $(this).parent().parent().find('.comm-parent').text();
        var artid = $(this).parent().parent().find('.comm-artid').text();
        if (Request['dateOrder'] === undefined) {
            Request['dateOrder'] = 1
        }
        if (Request['artid'] === undefined || Request['artid'] == null) {
            Request['artid'] = -1;
        }
        if (Request['page'] === undefined) {
            Request['page'] = 1;
        }
        if ($(this).find('span').text()=='文章'){
            var url= "<?php echo Url('admin/index/articleEdit',['artid'=>artids]); ?>";
            url=url.replace('artids',artid);
            window.location.href = url;
        }else{
            window.location.href = "<?php echo Url('admin/index/commentManagement'); ?>?artid=" + Request['artid'] + "&dateOrder=" + 2 + "&page=" + Request['page'] + "&reply=" + reply;

        }
    })
</script>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

