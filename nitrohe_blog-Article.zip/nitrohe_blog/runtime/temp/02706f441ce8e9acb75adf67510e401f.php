<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:64:"D:\wamp\www\nitrohe_blog/application/admin\view\index\index.html";i:1543831974;s:67:"D:\wamp\www\nitrohe_blog\application\admin\view\baseView\index.html";i:1543641067;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        
<div class="admin-index">
    <p>欢迎来到Nitrohe博客后台管理系统</p>
    <div class="index-left">
        <div class="fast-look">
            <p>快速概览</p>
            <span><i class="iconfont">&#xe633;</i> <a
                    href="<?php echo Url('admin/index/myArticle',['m'=>all]); ?>"><?php echo $artsCount; ?>篇文章</a></span>
            <span><i class="iconfont">&#xe674;</i> <a href="<?php echo Url('admin/index/myArticle',['m'=>draft]); ?>"><?php echo $draftsCount; ?>篇草稿</a></span>
            <span><i class="iconfont">&#xe535;</i> <a href="<?php echo Url('admin/index/commentManagement'); ?>"><?php echo $commCount; ?>条评论</a></span>
            <span><i class="iconfont">&#xe6b1;</i> <a
                    href="<?php echo Url('admin/index/articleTags'); ?>"><?php echo $tagscount; ?>个标签</a></span>

        </div>
        <div class="fast-draft">
            <p>快速草稿</p>
            标题:<input type="text" class="form-control" name="title" id="title">
            作者:<input type="text" class="form-control" name="author" id="author">
            草稿:
            <textarea   id="art-content">

             </textarea>
            <button class="btn save-draft">保存草稿</button>

        </div>
    </div>
        <div class="admim-active">
            <p>最近发布</p>
            <ul>
                <?php if(($recentArts==null)): ?>
                <li>文章空空如也</li>
                <?php else: if(is_array($recentArts) || $recentArts instanceof \think\Collection || $recentArts instanceof \think\Paginator): if( count($recentArts)==0 ) : echo "" ;else: foreach($recentArts as $key=>$ra): ?>
                <li><span><?php echo $ra['article_pushdate']; ?> </span> 由<span><?php echo $ra['article_author']; ?></span>发表<span><a href="<?php echo Url('admin/index/articleEdit',['artid'=>$ra['article_id']]); ?>"><?php echo $ra['article_title']; ?></a></span></li>
                <?php endforeach; endif; else: echo "" ;endif; endif; ?>
            </ul>
        </div>
        <div class="admim-active">
            <p>最近草稿</p>
            <ul>
                <?php if(($recentDrafts==null)): ?>
                <li>文章空空如也</li>
                <?php else: if(is_array($recentDrafts) || $recentDrafts instanceof \think\Collection || $recentDrafts instanceof \think\Paginator): if( count($recentDrafts)==0 ) : echo "" ;else: foreach($recentDrafts as $key=>$rd): ?>
                <li><span><?php echo $rd['article_pushdate']; ?> </span> 由<span><?php echo $rd['article_author']; ?></span>发表<span><a href="<?php echo Url('admin/index/articleEdit',['artid'=>$rd['article_id']]); ?>"><?php echo $rd['article_title']; ?></a></span></li>
                <?php endforeach; endif; else: echo "" ;endif; endif; ?>
            </ul>
        </div>
        <div class="admim-active">
            <p>最近评论</p>
            <ul>
                <?php if((recentComms==null)): ?>
                <li>评论空空如也</li>
                <?php else: if(is_array($recentComms) || $recentComms instanceof \think\Collection || $recentComms instanceof \think\Paginator): if( count($recentComms)==0 ) : echo "" ;else: foreach($recentComms as $key=>$rc): ?>
                <li><span><?php echo $rc['comment_date']; ?> </span> 由<span><?php echo $rc['comment_user']; ?></span>对文章<span><?php echo $rc['article_title']; ?>发表评论<span>
                    <a href="<?php echo Url('admin/index/articleEdit',['artid'=>$rc['article_id']]); ?>"><?php echo $rc['comment_content']; ?></a></span></li>
                <?php endforeach; endif; else: echo "" ;endif; endif; ?>
            </ul>
        </div>
        <!--<div class="clear"></div>-->
    <div class="clear"></div>
</div>
<script>
$('.save-draft').click(function () {

    var title=$('#title').val();
    var author=$('#author').val();
    var articleContent=$('#art-content').val();
    if ($.trim(title)==''||$.trim(author)==''||$.trim(articleContent)=='') {
        alert_fail('提示', '标题、作者或内容不能为空！');
        return false;
    }

    $.ajax({
        type: 'post',
        data: {
            'data': JSON.stringify({
                title: title,
                author: author,
                articleContent: articleContent,
            })
        },
        dataType: 'json',
        async: true,
        url:  '<?php echo Url("admin/index/articleSaveDraft"); ?>',
        success: function (data) {
            console.log(JSON.stringify(data));
            if (JSON.stringify(data) == 1) {
                alert_success_url('提示', '保存成功','<?php echo Url("admin/index/index"); ?>');
                setTimeout(function () {
                    $('textarea').val('');
                    $('input').val('');
                }, 2000)

            } else {
                alert_fail('提示', '保存失败');
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            // alert('错误-2');
            // alert(XMLHttpRequest.status);
            // alert(XMLHttpRequest.readyState);
            // alert(textStatus);
            alert_fail('提示', '未知错误');
        }

    })
})

</script>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

