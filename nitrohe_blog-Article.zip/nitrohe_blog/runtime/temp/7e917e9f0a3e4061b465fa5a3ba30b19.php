<?php if (!defined('THINK_PATH')) exit(); /*a:9:{s:64:"D:\wamp\www\nitrohe_blog/application/index\view\index\index.html";i:1543900009;s:67:"D:\wamp\www\nitrohe_blog\application\index\view\baseView\index.html";i:1543851767;s:64:"D:\wamp\www\nitrohe_blog\application\index\view\commom\menu.html";i:1543829025;s:69:"D:\wamp\www\nitrohe_blog\application\index\view\commom\usermodel.html";i:1538127531;s:71:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\timeball.html";i:1538127531;s:71:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\calendar.html";i:1538127531;s:81:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\articleRecommended.html";i:1538127531;s:70:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\artTags.html";i:1538127531;s:66:"D:\wamp\www\nitrohe_blog\application\index\view\commom\footer.html";i:1543968041;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $webtitle; ?></title>
    <meta name="renderer" content="webkit">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="applicable-device" content="pc,mobile">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="keywords" content="<?php echo $webconf['webconf_keywords']; ?>">
    <meta name="author" content="<?php echo $author; ?>">
    <meta name="description" content="<?php echo $desc; ?>">
    <meta property="og:title" content="<?php echo $webtitle; ?>">
    <meta property="og:author" content="<?php echo $webconf['webconf']['author']; ?>">
    <meta property="og:url" content="<?php echo $webconf['webconf']['demain']; ?>">
    <meta property="og:site_name" content="<?php echo $webtitle; ?>">
    <meta property="og:description" content="<?php echo $desc; ?>">
    <meta name="twitter:title" content="<?php echo $webtitle; ?>">
    <meta name="twitter:description" content="<?php echo $desc; ?>">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="/nitrohe_blog/public/static/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
    <script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/prism.css">
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/prism-toolbar.css">
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/jw_main.css">
    <script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
    <script>
        (function(){
            var bp = document.createElement('script');
            var curProtocol = window.location.protocol.split(':')[0];
            if (curProtocol === 'https') {
                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
            }
            else {
                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
            }
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(bp, s);
        })();
    </script>

</head>
<body>
<?php if(($webconf['webconf_indextopimg']!=null)): ?>
<style>
    .menu,.main,.footer{
        position: relative;
        bottom: 50px;
    }
</style>
<div class="topimg" style="min-width: 1250px" >
    <img src="//<?php echo $webconf['webconf_indextopimg']; ?>"  width="100%" height="200px">
    <!-- 设置图片的大小控制在260 -->
</div>
<?php endif; ?>
<div class="menu">
    
    <a href="" alt=""><img src="http://www.nitrohe.xin/Public/Home/imgs/logo_white_2.png" width="150"
height="26" style="float: left;margin-left: 40px;margin-top: 10px;"></a>
<div class="index-menu">
    <div>
        <ul>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index'); ?>" <?php if(($menuname['menu_name'] ==null)): ?> class="menu-activity" <?php endif; ?>>首页</a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['m'=>$menulist['menu_id']]); ?>"<?php if(($menuname['menu_name'] == $menulist['menuName'])): ?> class="menu-activity" <?php endif; ?>><?php echo $menulist['menuName']; ?></a>
                <ul class="submenu">
                    <?php if(is_array($menulist['subMenu']) || $menulist['subMenu'] instanceof \think\Collection || $menulist['subMenu'] instanceof \think\Paginator): if( count($menulist['subMenu'])==0 ) : echo "" ;else: foreach($menulist['subMenu'] as $key=>$subMenu): ?>
                    <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['m'=>$menulist['menu_id'],'t'=>$subMenu['types_id']]); ?>"><?php echo $subMenu['types_content']; ?></a></li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="input-group  input-search">
        <input class="form-control" type="text" id="keywords" placeholder="搜索文章" style="height: 40px">
        <span class="input-group-btn" id="search-inputs">
            <button class="btn btn-default" style="height: 40px;position: relative;right: 2px;"> <i class="iconfont">&#xe615;</i> </button>
        </span>
    </div>
</div>
<script>
    // console.log(decodeURI(encodeURI('的')))

    $('#search-inputs').click(function () {
        var keywords=$('#keywords').val();
        if (keywords!=''){

            var url="<?php echo Url('index/index/index',['keyword'=>keywords]); ?>";
            url=url.replace('keywords',(keywords))
            console.log(encodeURIComponent(url))
            window.location.href=encodeURI(encodeURI(url))
        }
    });

</script>
    
</div>
<div class="main">
    <div class="main-conternt">
        
<?php if(($flag != -1)): ?>
<div class="index-position">
        <span>当前位置:<a href="<?php echo Url('index/index/index'); ?>' ">首页>></a>
            <?php if(($flag==1||$flag==2)): ?>
            <a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['m'=>$menuname['menu_id']]); ?>"><?php echo $menuname['menu_name']; ?>>></a>
                <?php if(($flag ==1)): ?>
                    <a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['m'=>$menuname['menu_id'],'t'=>$typename['types_id']]); ?>"><?php echo $typename['types_content']; ?></a>
                <?php endif; endif; if(($flag ==4)): ?>
                标签>><?php echo $tagName; endif; if(($flag ==0)): ?>
            搜索结果:<?php echo $keyword; endif; ?>
        </span>
</div>
<?php endif; ?>
<div class="index-main">

    <div class="article-list">
        <?php if(is_array($article) || $article instanceof \think\Collection || $article instanceof \think\Paginator): if( count($article)==0 ) : echo "" ;else: foreach($article as $key=>$article): ?>
        <div class="article-breviary">
            <div class="art-bre-tit">
            <?php if(($article['article_type']!=null)): ?>    <span class="art-type">
                <?php if(($article['article_type']['types_content']!=null)): ?>
                <?php echo $article['article_type']['types_content']; endif; if(($article['article_type']['menu_name']!=null)): ?>
                <?php echo $article['article_type']['menu_name']; endif; ?>
                 </span><?php endif; ?>
                <a class="art-title" href="<?php echo Url('index/index/detail',['id'=>$article['article_id']]); ?>"> <?php echo $article['article_title']; ?></a>
            </div>
            <div class="art-bre-top">
                <div class="art-bre-left"
                     onclick="window.location.href='<?php echo Url('index/index/detail',['id'=>$article['article_id']]); ?>'">
                    <img src="<?php if(($article['article_imgSrc'] == null)): ?>//res.jianwoo.cn/jw.jpg
                    <?php else: ?>//<?php echo $article['article_imgSrc']; endif; ?>" width="200" alt="<?php echo $article['article_title']; ?>">
                    <div></div>
                </div>
                <div class="art-bre-right">
                    <span class="article-content-bre"><?php echo $article['article_gist']; ?></span>
                </div>
            </div>
            <div class="art-bre-info">
                <div>
                        <span class="art-author"><i class="iconfont">&#xe67a;</i>&nbsp;<?php echo $article['article_author']; ?></span>
                        <span class="art-date"><i class="iconfont">&#xe65d;</i>&nbsp;<?php echo $article['article_pushdate']; ?></span>
                        <span class="art-readers"><i class="iconfont">&#xe603;</i>&nbsp;<?php echo $article['article_readcount']; ?></span>
                        <a class="art-comment"
                               href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$article['article_id']]); ?>#comments">
                            <i class="iconfont">&#xe682;</i>&nbsp;<?php echo $article['article_commentCount']; ?>条评论</a>
                        <?php if(($article['article_isgoods'] == 1)): ?>
                        <span class="art-goods " style="color: red">
                            <i class="iconfont" style="color: red">&#xe502;</i>&nbsp;<?php echo $article['article_goodscount']; ?>
                        </span>
                        <?php else: ?>
                        <span class="art-goods before-goods-add"><i class="iconfont">&#xe64c;</i>
                            <?php echo $article['article_goodscount']; ?>
                        </span>
                        <span style="display: none" class="artid"><?php echo $article['article_id']; ?></span>

                        <?php endif; ?>
                </div>
                <div><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$article['article_id']]); ?>">阅读全文>></a></div>
            </div>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        <div><?php echo $page; ?></div>
    </div>
</div>
<script>
    $('.before-goods-add').click(function () {
        console.log('good')
        var goods = $(this).clone();
        goods.find('i').remove();
        // console.log(parseInt(goods.text()) + 1)
        // $(this).parent().css('display', 'none');
        // $('.goods-add').find('i').remove();
        $(this).html('<i class="iconfont" style="color: red">&#xe502;</i>' + (parseInt(goods.text()) + 1)).css('color', 'red');
        $(this).removeClass('before-goods-add');
        var artid = $(this).parent().find('.artid').text();
        console.log("id" + artid)
        $.ajax({
            type: 'post',
            data: {'data': JSON.stringify({goods: 1, article_id: parseInt(artid)})},
            dataType: 'json',
            async: true,
            url: "<?php echo Url('index/index/goodsAdd'); ?>",
            success: function (datas) {
                console.log(datas)
            },
            error: function () {
                console.log("error")
            }
        })
    })
    $(function () {
        $('.art-title').mouseover(function (e) {
            $(this).mousemove(function (e) {
                var top=$(this).offset().top;
                var left=$(this).offset().left;
                var x=e.pageX-left;
                var y=e.pageY-top;
                $(this).after('<span style="color:red" class="tit_alt">'+ $(this).text()+'</span>');
                $(this).parent().find('.tit_alt').css('left',x).css('top',y)
            })
        });
        $(document).on('mouseleave','.art-title',function () {
            // $(this).parent
            $(this).parent().find('.tit_alt').remove();
        });
    })

</script>

        <div class="usermodel">
            
            <div class="timeball">
 <canvas id="timeball"   width="310" height="300" ></canvas>
</div>
 <div class="calendar">
     <table>
         <thead><tr><td colspan="7"  > </td></tr></thead>
         <tbody id="cal-tb">
            <tr class="cal-week">
                <td><a>日</a></td>
                <td><a>一</a></td>
                <td><a>二</a></td>
                <td><a>三</a></td>
                <td><a>四</a></td>
                <td><a>五</a></td>
                <td><a>六</a></td>
            </tr>
         </tbody>
         <tfoot id="cal-foot"><tr><td colspan="7"></td></tr></tfoot>
     </table>

 </div>

 <script>
     $(document).ready(function () {
        var  artdays=<?php echo $artdays; ?>;


         var d=new Date();
         var year=d.getFullYear();
         var mon=d.getMonth();
         var day=d.getDate();
         var week=d.getDay();

         calShow(year,mon,day);
        function calShow(year,mon) {
            var df=new Date(year,mon,1);
            var firstdayweek=df.getDay();
            var dayadd=1;
            var  mondays=getMondays(year,mon+1);
            $('.calendar table>thead>tr>td').append( '<a>'+ (year+"年"+(mon+1)+"月") +"</a>" );
            for (var i=0;i<=5;i++){
                $('.calendar table>tbody').append('<tr></tr>');
                for (var j = 0; j < 7; j++) {
                    if (firstdayweek > j && i === 0) {
                        $('.calendar table>tbody>tr:last-child').append('<td></td>');
                    } else {
                        if (dayadd<=mondays){
                            $('.calendar table>tbody>tr:last-child').append('<td><a>' + (dayadd++) + '</a></td>');
                            if (dayadd-1===new Date().getDate()&&mon===new Date().getMonth()&&year===new Date().getFullYear()){
                                $('.calendar table>tbody>tr:last-child>td:last-child>a').addClass('cal-today');
                            }
                            for (index in artdays){
                                var pubtime=new Date(artdays[index]['article_pushdate']);
                                if (pubtime.getFullYear()===year&&pubtime.getMonth()===mon&&pubtime.getDate()===dayadd-1){
                                    $('.calendar table>tbody>tr:last-child>td:last-child>a').addClass('cal-artpub');
                                    var url='<?php echo Url("index/index/index",["d"=>ddddd]); ?>';
                                    url=url.replace('ddddd',year+""+(mon+1<10?'0'+(mon+1):(mon+1))+(dayadd-1<10?'0'+(dayadd-1):(dayadd-1)));
                                    $('.calendar table>tbody>tr:last-child>td:last-child>a'). attr('href',url);
                                }
                            }

                        }else{
                            $('.calendar table>tbody>tr:last-child').append('<td></td>');
                        }
                    }
                }

            }
            $('#cal-tb').trigger('create');
            $('#cal-foot>tr>td').append("<a class='pre-mon'><<"+(mon===0?12:mon)+"月</a>");
            $('#cal-foot>tr>td').append("<a class='next-mon'>>>"+(mon+2===13?1:mon+2)+"月</a>");



        }
         var tmon=mon;
         var tyear=year;
         $('.calendar').on('click','.pre-mon',function () {
             $('.calendar table>thead>tr>td>a').remove();
             $('.calendar table>tfoot>tr>td>a').remove();
             $('.calendar table>tbody>tr:not(.cal-week)').remove();
             if (--tmon<0){
                 tmon=11;
                 tyear--;
             }
             calShow(tyear,tmon);
         });
         $('.calendar').on('click','.next-mon',function () {
             $('.calendar table>thead>tr>td>a').remove();
             $('.calendar table>tfoot>tr>td>a').remove();
             $('.calendar table>tbody>tr:not(.cal-week)').remove();

             if (++tmon>11){
                 tmon=0;
                 tyear++;
             }
             calShow(tyear,tmon);
         });
        function  isloop(year) {
            if(year%4===0&&year%100!==0||year%400===0){
                return true
            }else{
                return false;
            }
        }
        function  getMondays(year,mon) {
            var day=new Date(year,mon,0);
            return day.getDate();
        }

     })


 </script>
<div class="art-box">
    <div class="artb-title">
        <span>最新文章</span>
        <span>随机推荐</span>
        <span>热门文章</span>
    </div>
    <div class="newest-art display">
        <ul>
            <?php if(is_array($newestArt) || $newestArt instanceof \think\Collection || $newestArt instanceof \think\Paginator): if( count($newestArt)==0 ) : echo "" ;else: foreach($newestArt as $key=>$news): ?>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$news['article_id']]); ?>"><?php echo sub_str($news['article_title'],18); ?></a>
                <a style="display: none" class="tit-dis-no"><?php echo $news['article_title']; ?></a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="random-art hidden">
        <ul>
            <?php if(is_array($randomtArt) || $randomtArt instanceof \think\Collection || $randomtArt instanceof \think\Paginator): if( count($randomtArt)==0 ) : echo "" ;else: foreach($randomtArt as $key=>$random): ?>
            <li>
                <a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$random['article_id']]); ?>"><?php echo sub_str($random['article_title'],18); ?></a>
                    <a style="display: none" class="tit-dis-no"><?php echo $random['article_title']; ?></a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="hot-art hidden">
        <ul>
            <?php if(is_array($hotArt) || $hotArt instanceof \think\Collection || $hotArt instanceof \think\Paginator): if( count($hotArt)==0 ) : echo "" ;else: foreach($hotArt as $key=>$hot): ?>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$hot['article_id']]); ?>"><?php echo sub_str($hot['article_title'],18); ?></a>
                <a style="display: none" class="tit-dis-no"><?php echo $hot['article_title']; ?></a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>
<script>
    $(function () {

        var i = 0;
        $('.artb-title>span').eq(0).addClass('art-titlehover');
        showArtbox();

        function showArtbox() {
            var d = i % 3;
            $('.artb-title>span').eq(d).addClass('art-titlehover');
            $('.artb-title>span').eq((d + 1) % 3).removeClass('art-titlehover');
            $('.artb-title>span').eq((d + 2) % 3).removeClass('art-titlehover');
            $('.art-box>div:not(.artb-title)').eq(d).removeClass('hidden');
            $('.art-box>div:not(.artb-title)').eq(d).addClass('display');
            $('.art-box>div:not(.artb-title)').eq((d + 1) % 3).addClass('hidden');
            $('.art-box>div:not(.artb-title)').eq((d + 2) % 3).addClass('hidden');
            i++;
            $('.artb-title>span').mouseover(function () {
                clearInterval(inter);
            })
        }

        var inter = setInterval(function () {
            showArtbox();
        }, 2000)

        $('.artb-title>span').each(function (index) {
            $(this).mouseover(function () {
                $('.artb-title>span').eq(index).addClass('art-titlehover');
                $('.artb-title>span').eq((index + 1) % 3).removeClass('art-titlehover');
                $('.artb-title>span').eq((index + 2) % 3).removeClass('art-titlehover');
                $('.art-box>div:not(.artb-title)').eq(index).removeClass('hidden');
                $('.art-box>div:not(.artb-title)').eq(index).addClass('display');
                $('.art-box>div:not(.artb-title)').eq((index + 1) % 3).addClass('hidden');
                $('.art-box>div:not(.artb-title)').eq((index + 2) % 3).addClass('hidden');
            });
        })
        $('.artb-title>span').mouseleave(function () {
            clearInterval(inter);
            inter = setInterval(function () {
                showArtbox();
            }, 2000);

        })
            $('.art-box ul>li').mouseover(function (e) {
                $(this).mousemove(function (e) {
                    var x=e.pageX;
                    var y=e.pageY;
                    var xx=e.screenX;
                    var yy=e.screenY;
                    $(this).after('<span style="color:red" class="tit_alt">'+ $(this).find('.tit-dis-no').text()+'</span>');
                    $(this).parent().find('.tit_alt').css('position','absolute').css('left',x).css('top',y-250)
                })
            });
            $(document).on('mouseleave','.art-box ul>li',function () {
                // $(this).parent
                $(this).parent().find('.tit_alt').remove();
            });
            var length=$('.art-box ul>li').length;
            $('.art-box ul>li').each(function (index) {
               var  li=length/3;
                $($(this).children('a').get(0)).before('<span>'+parseInt(index%li+1)+'</span>');

                    if (parseInt(index%li+1)===1){
                        $(this).children('span').addClass('li-no-one');
                    }else  if (parseInt(index%li+1)===2){
                    $(this).children('span').addClass('li-no-two');
                    }else if (parseInt(index%li+1)===3){
                        $(this).children('span').addClass('li-no-three');
                    } else {
                        $(this).children('span').addClass('li-no-othor');
                    }
            });

    });


</script>
<?php if(($taglist!=null)): ?>
<div class="art-tags">
    <p>标签云集</p>
     <div style="position: relative">
         <?php if(is_array($taglist) || $taglist instanceof \think\Collection || $taglist instanceof \think\Paginator): if( count($taglist)==0 ) : echo "" ;else: foreach($taglist as $key=>$tags): ?>
         <span>
             <a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['tagid'=>$tags['tags_id']]); ?>"><?php echo $tags['tags_content']; ?></a>
             <a style="display: none" class="tags-id"><?php echo $tags['count']; ?></a>
         </span>
         <?php endforeach; endif; else: echo "" ;endif; ?>
     </div>
 </div>
<?php endif; ?>
 <script>
     spans = $('.art-tags>div').find('span');
     for (var i = 0; i < spans.length; i++) {
         var color = Math.random();
         var r = parseInt((color * (i + 1) * 1234) % 254);
         var g = parseInt((color * (i + 1) * 4321) % 254);
         var b = parseInt((color * (i + 1) * 2222) % 254);
         $(spans[i]).css("background-color", "rgba(" + r + "," + g + "," + b + ",0.1)")
         $(spans[i]).css("border", "  1px rgba(" + r + "," + g + "," + b + ",1) solid")
     }


     $(function () {
         $('.art-tags span ').mouseover(function (e) {
             $(this).mousemove(function (e) {
                 var top=$(this).offset().top;
                 var left=$(this).offset().left;
                 var x=e.pageX-left;
                 var y=e.pageY-top;
                 $(this).after('<span style="color:red" class="tit_alt">'+ $(this).find('.tags-id').text()+'个话题</span>');
                 $(this).parent().find('.tit_alt').css('left',x).css('top',y+20)
             })
         });
         $(document).on('mouseleave','.art-tags span ',function () {
             // $(this).parent
             $(this).parent().find('.tit_alt').remove();
         });
     })
 </script>
            
        </div>
        <div class="clear"></div>
    </div>
</div>
<div class="footer">
    
    <div>
    <?php echo $foot; ?>
    <br/>
    <span id="copyright">Copyright © 2017-<span></span></span>
    <span><a href="https://github.com/fank1314"  target="_blank">2016级计算机应用技术 · LeeSlow Fank
    </a> </span>
    <span><a href="http://www.miitbeian.gov.cn/"> <?php echo $webrecord; ?></a></span>
</div>
<script>

    $('#copyright>span').text(new Date().getFullYear())

</script>
    
</div>


<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/prism.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/prism-line-numbers.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/prism-toolbar.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/clipboard.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/timeballs.js"></script>
</body>
</html>