<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:68:"D:\wamp\www\jianwoo-master/application/admin\view\index\dynamic.html";i:1538127531;s:69:"D:\wamp\www\jianwoo-master\application\admin\view\baseView\index.html";i:1543641067;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/jianwoo-master/public/static/layui/css/layui.css">
<script type="text/javascript" src="/jianwoo-master/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/js/common.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/jianwoo-master/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/jianwoo-master/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        
<div class="dynamic">
    <p>动态</p>
    <div class="newest-visit">
        <p>最新访问</p>
        <ul>
            <?php if(is_array($visit) || $visit instanceof \think\Collection || $visit instanceof \think\Paginator): if( count($visit)==0 ) : echo "" ;else: foreach($visit as $key=>$v): ?>
            <li>来自ip为<span><?php echo $v['visit_ip']; ?></span>的网友在 <span><?php echo $v['visit_date']; ?></span>访问了文章
                <span><a href="<?php echo Url('admin/index/articleEdit',['artid'=>$v['article_id']]); ?>"><?php echo $v['article_title']; ?></a></span></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="not-read-comms">
        <p>未读评论</p>
        <ul>
            <?php if(($notreadcomms|sizeof==0)): ?>
               <li>暂没有未读评论！</li>
            <?php else: if(is_array($notreadcomms) || $notreadcomms instanceof \think\Collection || $notreadcomms instanceof \think\Paginator): if( count($notreadcomms)==0 ) : echo "" ;else: foreach($notreadcomms as $key=>$nrc): ?>
                <li><span><?php echo $nrc['comment_date']; ?></span><span><?php echo $nrc['comment_user']; ?></span>的网友评论了文章
                  <span>  <a href="<?php echo Url('admin/index/articleEdit',['artid'=>$nrc['article_id']]); ?>"><?php echo $nrc['article_title']; ?></a></span>:
                    <span><a href="<?php echo Url('admin/index/articleEdit',['artid'=>$nrc['article_id']]); ?>"><?php echo $nrc['comment_content']; ?></a></span></li>
                <?php endforeach; endif; else: echo "" ;endif; endif; ?>
        </ul>
        <div class="page">
            <div><?php echo $page; ?></div>

        </div>
    </div>
</div>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

