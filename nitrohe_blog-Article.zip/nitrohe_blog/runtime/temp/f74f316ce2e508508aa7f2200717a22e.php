<?php if (!defined('THINK_PATH')) exit(); /*a:9:{s:65:"D:\wamp\www\nitrohe_blog/application/index\view\index\detail.html";i:1543843973;s:67:"D:\wamp\www\nitrohe_blog\application\index\view\baseView\index.html";i:1543851767;s:64:"D:\wamp\www\nitrohe_blog\application\index\view\commom\menu.html";i:1543829025;s:69:"D:\wamp\www\nitrohe_blog\application\index\view\commom\usermodel.html";i:1538127531;s:71:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\timeball.html";i:1538127531;s:71:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\calendar.html";i:1538127531;s:81:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\articleRecommended.html";i:1538127531;s:70:"D:\wamp\www\nitrohe_blog\application\index\view\usermodel\artTags.html";i:1538127531;s:66:"D:\wamp\www\nitrohe_blog\application\index\view\commom\footer.html";i:1543968041;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $webtitle; ?></title>
    <meta name="renderer" content="webkit">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="applicable-device" content="pc,mobile">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="keywords" content="<?php echo $webconf['webconf_keywords']; ?>">
    <meta name="author" content="<?php echo $author; ?>">
    <meta name="description" content="<?php echo $desc; ?>">
    <meta property="og:title" content="<?php echo $webtitle; ?>">
    <meta property="og:author" content="<?php echo $webconf['webconf']['author']; ?>">
    <meta property="og:url" content="<?php echo $webconf['webconf']['demain']; ?>">
    <meta property="og:site_name" content="<?php echo $webtitle; ?>">
    <meta property="og:description" content="<?php echo $desc; ?>">
    <meta name="twitter:title" content="<?php echo $webtitle; ?>">
    <meta name="twitter:description" content="<?php echo $desc; ?>">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="/nitrohe_blog/public/static/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
    <script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/prism.css">
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/prism-toolbar.css">
    <link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/jw_main.css">
    <script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
    <script>
        (function(){
            var bp = document.createElement('script');
            var curProtocol = window.location.protocol.split(':')[0];
            if (curProtocol === 'https') {
                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
            }
            else {
                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
            }
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(bp, s);
        })();
    </script>

</head>
<body>
<?php if(($webconf['webconf_indextopimg']!=null)): ?>
<style>
    .menu,.main,.footer{
        position: relative;
        bottom: 50px;
    }
</style>
<div class="topimg" style="min-width: 1250px" >
    <img src="//<?php echo $webconf['webconf_indextopimg']; ?>"  width="100%" height="200px">
    <!-- 设置图片的大小控制在260 -->
</div>
<?php endif; ?>
<div class="menu">
    
    <a href="" alt=""><img src="http://www.nitrohe.xin/Public/Home/imgs/logo_white_2.png" width="150"
height="26" style="float: left;margin-left: 40px;margin-top: 10px;"></a>
<div class="index-menu">
    <div>
        <ul>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index'); ?>" <?php if(($menuname['menu_name'] ==null)): ?> class="menu-activity" <?php endif; ?>>首页</a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['m'=>$menulist['menu_id']]); ?>"<?php if(($menuname['menu_name'] == $menulist['menuName'])): ?> class="menu-activity" <?php endif; ?>><?php echo $menulist['menuName']; ?></a>
                <ul class="submenu">
                    <?php if(is_array($menulist['subMenu']) || $menulist['subMenu'] instanceof \think\Collection || $menulist['subMenu'] instanceof \think\Paginator): if( count($menulist['subMenu'])==0 ) : echo "" ;else: foreach($menulist['subMenu'] as $key=>$subMenu): ?>
                    <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['m'=>$menulist['menu_id'],'t'=>$subMenu['types_id']]); ?>"><?php echo $subMenu['types_content']; ?></a></li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="input-group  input-search">
        <input class="form-control" type="text" id="keywords" placeholder="搜索文章" style="height: 40px">
        <span class="input-group-btn" id="search-inputs">
            <button class="btn btn-default" style="height: 40px;position: relative;right: 2px;"> <i class="iconfont">&#xe615;</i> </button>
        </span>
    </div>
</div>
<script>
    // console.log(decodeURI(encodeURI('的')))

    $('#search-inputs').click(function () {
        var keywords=$('#keywords').val();
        if (keywords!=''){

            var url="<?php echo Url('index/index/index',['keyword'=>keywords]); ?>";
            url=url.replace('keywords',(keywords))
            console.log(encodeURIComponent(url))
            window.location.href=encodeURI(encodeURI(url))
        }
    });

</script>
    
</div>
<div class="main">
    <div class="main-conternt">
        
<div class="index-main">
    <div class="detail">
        <div class="position">
            <span>当前位置:<a href="<?php echo Url('index/index/index'); ?>' ">首页>></a>
                <?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): if( count($nav)==0 ) : echo "" ;else: foreach($nav as $key=>$nav): ?>
                    <a href="<?php echo $nav['href']; ?>"><?php echo $nav['name']; ?></a>>>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <?php echo $articleCon['article_title']; ?>
            </span>
        </div>
        <div class="art-con">
            <div class="art-det-info" id="art-det-info">
                <div><span><?php echo $articleCon['article_title']; ?></span></div>
                  <!-- 开始设置好需要调整titles的部分 -->
                <div class="art-titles">
                    <span class="art-author"><i class="iconfont">&#xe67a;</i> :<?php echo $articleCon['article_author']; ?></span>
                    <span class="art-date"><i class="iconfont">&#xe65d;</i>:<?php echo $articleCon['article_pushdate']; ?></span>
                    <span class="art-type"><i class="iconfont">&#xe618;</i>:<?php echo $typecon; ?></span>
                    <span class="art-readers"><i class="iconfont">&#xe603;</i>:<?php echo $articleCon['article_readcount']; ?></span>
                </div>
            </div>

            <div class="art-txt">
                <?php echo $artcontext; ?>
            </div>
        </div>
    </div>
    <div class="art-foot">
        <?php if(($tags!=null)): ?>
        <div class="artd-tags">
            标签:
            <?php if(is_array($tags) || $tags instanceof \think\Collection || $tags instanceof \think\Paginator): if( count($tags)==0 ) : echo "" ;else: foreach($tags as $key=>$tags): ?>
            <span><?php echo $tags['tags_content']; ?></span>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <?php endif; ?>
        <div class="art-copyright">
            <span><b>版权声明:</b>本站原创文章，于<?php echo $article['article_modified']; ?>最后修改，由<?php echo $articleCon['article_author']; ?>发表</span>
            <span><b>转载请注明:</b><?php echo $articleCon['article_title']; ?>| Nitrohe博客</span>
        </div>

    </div>
    <div class="art-goods">
        <?php if(($goodsAdd == 1)): ?>
        <div class="goods-add " style="color: red">
            <i class="iconfont" style="color: red">&#xe672;</i></br><?php echo $articleCon['article_goodscount']; ?>
        </div>
        <?php else: ?>
        <div class="goods-add before-goods-add"><i class="iconfont" id="goodsbefore">&#xe63a;</i></br>
            <?php echo $articleCon['article_goodscount']; ?>
        </div>

        <?php endif; ?>
    </div>
    <div class="comment" id="comments">
        <div class="comment-input">
            <div>
                <div><span>评论</span></div>
            </div>
            <div>
            <textarea rows="5" cols="80">

            </textarea>
            </div>
            <div class="comment-user">
                <div>
                    <div>
                        <div class="input-group ">
                            <span class="input-group-addon " id="usernames"><i class="iconfont">&#xe501;</i></span>
                            <input type="text" class="form-control  username" placeholder="请输入昵称" id="username"
                                   aria-describedby="usernames">
                        </div>
                    </div>
                    <div>
                        <div class="input-group ">
                            <span class="input-group-addon " id="qqq"><i class="iconfont">&#xe619;</i></span>
                            <input type="text" class="form-control qq" placeholder="您的qq" id="qq"
                                   aria-describedby="qqq">
                        </div>
                    </div>
                </div>

                <div>
                    <button class="btn comment-btn">提交评论</button>
                </div>
            </div>

        </div>
        <div class="comment-list">
            <?php if(($commentlist==null)): ?>
            暂无评论！
            <?php endif; if(is_array($commentlist) || $commentlist instanceof \think\Collection || $commentlist instanceof \think\Paginator): if( count($commentlist)==0 ) : echo "" ;else: foreach($commentlist as $key=>$comment): ?>
            <div class="comment-unit">
                <div class="comment-info">
                    <span><img src="<?php echo $comment['comment_headimg']; ?>" width="30"></span><span><?php echo $comment['comment_user']; ?></span><span><?php echo $comment['comment_date']; ?></span>
                    <span><?php echo $comment['comment_floors']; ?>楼</span><span style="display: none"><?php echo $comment['comment_id']; ?></span>
                </div>
                <div class="comment-con">
                    <span><?php echo $comment['comment_content']; ?></span>
                </div>
                <div class="comment-op">
                    <?php if(($comment['comment_isgoods'] == 1)): ?><span class="after-goods" style="color:red"><i
                        class="iconfont" style="color: red">&#xe502;</i>&nbsp;赞(<?php echo $comment['comment_goodscount']; ?>)</span>
                    <?php else: ?><span><i class="iconfont">&#xe64c;</i>&nbsp;赞(<?php echo $comment['comment_goodscount']; ?>)</span>
                    <?php endif; ?>
                    <span><i class="iconfont">&#xe682;</i>&nbsp;评论</span>
                </div>


                <div class="reply-comment">
                    <?php if(is_array($comment['comment_reply']) || $comment['comment_reply'] instanceof \think\Collection || $comment['comment_reply'] instanceof \think\Paginator): if( count($comment['comment_reply'])==0 ) : echo "" ;else: foreach($comment['comment_reply'] as $key=>$reply): ?>
                    <div class="comment-unit">
                        <div class="comment-info">
                        <span><img
                                src="<?php echo $reply['comment_headimg']; ?>" width="30"></span><span><?php echo $reply['comment_user']; ?>回复<?php echo $reply['comment_parent_user']; ?></span><span><?php echo $reply['comment_date']; ?></span>
                                                    <span style="display: none"><?php echo $reply['comment_id']; ?></span>
                                                </div>
                                                <div class="comment-con">
                        <span><?php echo $reply['comment_content']; ?>
                        </span>
                        </div>
                        <div class="comment-op">
                            <?php if(($reply['comment_isgoods'] ==1)): ?> <span class="after-goods" style="color:red"><i
                                class="iconfont" style="color: red">&#xe502;</i>&nbsp;赞(<?php echo $reply['comment_goodscount']; ?>)</span>
                            <?php else: ?> <span><i class="iconfont">&#xe64c;</i>&nbsp;赞(<?php echo $reply['comment_goodscount']; ?>)</span>
                            <?php endif; ?>
                            <span><i class="iconfont">&#xe682;</i>&nbsp;评论</span></div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </div>
    </div>

    <div class="page-foot"></div>
</div>
<input type="hidden" id="commlastid" value="<?php echo $commlastid; ?>">
<script>
 $(document).ready(function () {
     // if (<?php echo $goodsAdd; ?> == 1) {
        //     $(".goods-add").css('color', 'red');
        //     $('.goods-add').html('<i class="iconfont" id="goodsafter">&#xe672;</i></br><?php echo $articleCon['article_goodscount']; ?>').css('display', 'block')
        // }
        var xmlbj;
        if (window.XMLHttpRequest) {
            xmlbj = new XMLHttpRequest();
        } else {
            xmlbj = new ActiveXObject('Microsoft.XMLHTTP');
        }
        xmlbj.open('GET','<?php echo Url("index/index/addPv",["id"=>$articleCon['article_id']]); ?>',true);
        xmlbj.send()






    spans = $('.artd-tags').find('span');
    // spans=document.getElementsByTagName("span")
    for (var i = 0; i < spans.length; i++) {
        var color = Math.random();
        var r = parseInt((color * (i + 1) * 1234) % 254);
        var g = parseInt((color * (i + 1) * 4321) % 254);
        var b = parseInt((color * (i + 1) * 2222) % 254);
        $(spans[i]).css("background-color", "rgba(" + r + "," + g + "," + b + ",0.1)")
        $(spans[i]).css("border", "  1px rgba(" + r + "," + g + "," + b + ",1) solid")

    }
    $('#goodsbefore').click(function () {
        var goods = $('.goods-add').clone();
        goods.find('i').remove();
        // $(this).parent().css('display', 'none');
        // $('.goods-add').find('i').remove();
        $('.goods-add').html('<i style="color:red!important;" class="iconfont" id="goodsafter">&#xe672;</i></br>' + (parseInt(goods.text()) + 1)).css('color', 'red');
        $('.goods-add').removeClass('before-goods-add');
        $.ajax({
            type: 'post',
            data: {'data': JSON.stringify({goods: 1, article_id: "<?php echo $articleCon['article_id']; ?>"})},
            dataType: 'json',
            async: true,
            url: "<?php echo Url('index/index/goodsAdd'); ?>",
            success: function (datas) {
                console.log(datas)


            },
            error: function () {
                console.log("error")
            }
        })
    })
    // console.log(<?php echo $goodsAdd; ?>)

    var flag = 0;
    var $comment_input = '        <div class="comment-input" >' +
        '                    <div style="display: none">' +
        '                        <div><span></span></div>' +
        '                    </div>' +
        '                    <div>' +
        '                            <textarea id="comment-replay-text" rows="5" cols="80">' +
        '' +
        '                            </textarea>' +
        '                    </div>' +
        '                    <div class="comment-user">' +
        '                        <div>' +
        '                            <div>' +
        '                                <div class="input-group ">' +
        '                                    <span class="input-group-addon" id="replay-username1"><i' +
        '                                            class="iconfont">&#xe501;</i></span>' +
        '                                    <input type="text" class="form-control username" placeholder="请输入昵称"' +
        '                                           aria-describedby="replay-username1">' +
        '                                </div>' +
        '                            </div>' +
        '                            <div>' +
        '                                <div class="input-group ">' +
        '                                        <span class="input-group-addon" id="replay-qq1"><i' +
        '                                                class="iconfont">&#xe619;</i></span>' +
        '                                    <input type="text" class="form-control qq" placeholder="您的qq"' +
        '                                           aria-describedby="replay-qq1">' +
        '                                </div>' +
        '                            </div>' +
        '                        </div>' +
        '' +
        '                        <div>' +
        '                            <button class="btn comment-btn">提交评论</button>' +
        '                        </div>' +
        '                    </div>' +
        '' +
        '                </div>';
    comment_input = $.parseHTML($comment_input);
    $('.comment-list').on('click', 'div.comment-op span:nth-child(2)', function () {
        if ($(this).parent().next().attr('class') != 'comment-input' ) {
            $(this).parent().after($comment_input);
            // flag = 1;
        } else {
            // $comment_input.remove();
            $(this).parent().parent().find('.comment-input').remove();
            // flag = 0;
        }
    })


    //评论提交
    var commid =  $('#commlastid').val() + 1;
    $('.comment').on('click', '.comment-btn', function () {
        var commentext = $(this).parent().parent().parent().find('textarea').val();
        var username = $(this).parent().parent().parent().find('.username').val();
        var qq = $(this).parent().parent().parent().find('.qq').val();
        var artId = "<?php echo $articleCon['article_id']; ?>";
        var curtime = formatDate(new Date().getTime());
        var addcom = null;
        var info = null;
        var replyId = null;
        var index = null;
        var headImgUrl = "/nitrohe_blog/public/static/headimg/" + Math.ceil(Math.random() * 10) + ".jpg";
        var $thisfourpars = $(this).parent().parent().parent().parent();
        var tarlink;
        console.log("imgurl" + headImgUrl);
        if (commentext == null || commentext.trim(' ') == '' || commentext == '' || commentext == ' ') {
            alert_fail('提示', '评论内容不能为空！');
            return false;
        }
        if (username == null || username.trim(' ') == '' || username == '' || username == ' ') {
            alert_fail('提示', '用户名不能为空！');
            return false;
        }

        var parentName = $(this).parent().parent().parent().parent().find('.comment-info>span:nth-child(2)').text();
        if ((index = parentName.indexOf('回')) >= 0) {
            parentName = parentName.substring(0, index)
        }
        if ($thisfourpars.attr('class') == 'comment') {
            tarlink = $('.comment>.comment-list>.comment-unit:last-child');
            tarlink.attr('id', 'cur-comment')
            addcom = $('.comment-list');
            info = ' <div class="comment-unit">' +
                '                    <div class="comment-info">' +
                '                            <span><img src="' + headImgUrl + '" width="30"></span><span>' + username + '</span>' +
                '                               <span> ' + curtime + '</span> ' +
                '                               <span style="display: none">' + commid + '</span>' +
                '                    </div>' +
                '                    <div class="comment-con">' +
                '                        <span>' + commentext + '</span>' +
                '                    </div>' +
                '                <div class="comment-op"><span><i class="iconfont">&#xe64c;</i>&nbsp;赞(0)</span><span><i' +
                '                            class="iconfont">&#xe682;</i>&nbsp;评论</span></div>' +
                '                <div class="reply-comment">' +
                '                                    </div> </div> ';

            console.log('commlist');

            replyId = -1;
            commid++;
        } else {
            if ($thisfourpars.parent().attr('class') == "comment-list") {
                addcom = $(this).parent().parent().parent().next()
                console.log('if' + addcom.attr('class'))
            } else {
                addcom = $thisfourpars.parent();
                console.log('else' + addcom.attr('class'))
            }
            tarlink = $('.reply-comment>.comment-unit:last-child');
            tarlink.attr('id', 'cur-comment')
            // 1763754
            info = ' <div class="comment-unit " id="cur-comment">' +
                '                    <div class="comment-info">' +
                '                             <span><img src="' + headImgUrl + '" width="30"></span>' + '<span>' + username + '回复 ' + parentName + '</span>' +
                '<span> ' + curtime + '</span> ' +
                '<span style="display: none">' + commid + '</span>' +
                '                    </div>' +
                '                    <div class="comment-con">' +
                '                        <span>' + commentext + '</span>' +
                '                    </div>' +
                '                <div class="comment-op"><span><i class="iconfont">&#xe64c;</i>&nbsp;赞(0)</span><span><i' +
                '                            class="iconfont">&#xe682;</i>&nbsp;评论</span></div>' +
                '                     </div>   ';
            replyId = $(this).parent().parent().parent().parent().find('.comment-info span:last-child ').eq(0).text();
              console.log(replyId)
            // console.log($(this).parent().parent().parent().parent().attr('class'))
            // console.log($(this).parent().parent().parent().parent().html())
            commid++;
        }


        // console.log(commentext+username)
        $commentId = $thisfourpars.find('.comment-info span:last-child')
        console.log("comid   :" + replyId)
        // if(!(parseInt($commentId.text())>0)){
        //     console.log("aa")v
        // }
        $.ajax({
            type: 'post',
            data: {
                'data': JSON.stringify({
                    commenttext: commentext,
                    username: username,
                    qq: qq,
                    artId: artId,
                    comment_parent: replyId,
                    headimgUrl: headImgUrl
                })
            },
            dataType: 'json',
            url: "<?php echo Url('index/index/addComment'); ?>",
            success: function (data) {
                console.log("com" + JSON.stringify(data));

                var html = $.parseHTML(info);
                addcom.append(html)
                alert_success_url('提示', '评论成功', '#cur-comment');
                setTimeout(function () {
                    tarlink.removeAttr('id');
                }, 4000)
                $('textarea').val('');
                $('.qq').val('');
                $('.username').val('');
            },
            error: function () {
                alert_fail('提示', '未知错误')
            }


        })
        // console.log(commentext+qq+username)
        if ($thisfourpars.attr('class') != 'comment') {
            $tmpthispars = $(this).parent().parent().parent();
            setTimeout(function () {
                $tmpthispars.remove();

            }, 2000)

        }
    })

    //评论点赞
    $('.comment-list').on('click', 'div.comment-op span:nth-child(1)', function () {
        var $goodscommentId = $(this).parent().parent().find('div.comment-info>span:last-child').eq(0).text();
        var re = $(this).parent().parent().find('div.comment-info:first-child>span:last-child');
        // console.log("aa" + $(this).parent().parent().html())
        console.log($goodscommentId)
        var $thisclone = $(this).clone();
        $thisclone.find('i').remove();
        var thistext = $thisclone.text().trim(' ');
        thistext = parseInt(thistext.substring(2, thistext.length - 1)) + 1;
        // console.log(thistext)
        $(this).html('<i class="iconfont" style="color: red">&#xe502;</i>&nbsp;赞(' + thistext + ')').css('color', 'red')
        $.ajax({
            type: 'post',
            dataType: 'json',
            data: {'data': JSON.stringify({comId: $goodscommentId})},
            url: '<?php echo url("index/index/addCommentGoods"); ?>',
            success: function (data) {
                console.log(data)
            }, error: function () {

            }


        })
    })
    Prism.plugins.toolbar.registerButton('select-all', function(env) {
        var button = document.createElement('button');
        button.innerHTML = '全选';

        button.addEventListener('click', function () {
            // Source: http://stackoverflow.com/a/11128179/2757940
            if (document.body.createTextRange) { // ms
                var range = document.body.createTextRange();
                range.moveToElementText(env.element);
                range.select();
            } else if (window.getSelection) { // moz, opera, webkit
                var selection = window.getSelection();
                var range = document.createRange();
                range.selectNodeContents(env.element);
                selection.removeAllRanges();
                selection.addRange(range);
            }
        });

        return button;
    });
    Prism.plugins.toolbar.registerButton('copy-to-clipboard', function (env) {
        var linkCopy = document.createElement('a');
        linkCopy.textContent = '复制';

        if (!ClipboardJS) {
            callbacks.push(registerClipboard);
        } else {
            registerClipboard();
        }

        return linkCopy;

        function registerClipboard() {
            var clip = new ClipboardJS(linkCopy, {
                'text': function () {
                    return env.code;
                }
            });

            clip.on('success', function() {
                linkCopy.textContent = '已复制';

                resetText();
            });
            clip.on('error', function () {
                linkCopy.textContent = 'Press Ctrl+C to copy';

                resetText();
            });
        }

        function resetText() {
            setTimeout(function () {
                linkCopy.textContent = '复制';
            }, 5000);
        }
    });


 })

</script>

        <div class="usermodel">
            
            <div class="timeball">
 <canvas id="timeball"   width="310" height="300" ></canvas>
</div>
 <div class="calendar">
     <table>
         <thead><tr><td colspan="7"  > </td></tr></thead>
         <tbody id="cal-tb">
            <tr class="cal-week">
                <td><a>日</a></td>
                <td><a>一</a></td>
                <td><a>二</a></td>
                <td><a>三</a></td>
                <td><a>四</a></td>
                <td><a>五</a></td>
                <td><a>六</a></td>
            </tr>
         </tbody>
         <tfoot id="cal-foot"><tr><td colspan="7"></td></tr></tfoot>
     </table>

 </div>

 <script>
     $(document).ready(function () {
        var  artdays=<?php echo $artdays; ?>;


         var d=new Date();
         var year=d.getFullYear();
         var mon=d.getMonth();
         var day=d.getDate();
         var week=d.getDay();

         calShow(year,mon,day);
        function calShow(year,mon) {
            var df=new Date(year,mon,1);
            var firstdayweek=df.getDay();
            var dayadd=1;
            var  mondays=getMondays(year,mon+1);
            $('.calendar table>thead>tr>td').append( '<a>'+ (year+"年"+(mon+1)+"月") +"</a>" );
            for (var i=0;i<=5;i++){
                $('.calendar table>tbody').append('<tr></tr>');
                for (var j = 0; j < 7; j++) {
                    if (firstdayweek > j && i === 0) {
                        $('.calendar table>tbody>tr:last-child').append('<td></td>');
                    } else {
                        if (dayadd<=mondays){
                            $('.calendar table>tbody>tr:last-child').append('<td><a>' + (dayadd++) + '</a></td>');
                            if (dayadd-1===new Date().getDate()&&mon===new Date().getMonth()&&year===new Date().getFullYear()){
                                $('.calendar table>tbody>tr:last-child>td:last-child>a').addClass('cal-today');
                            }
                            for (index in artdays){
                                var pubtime=new Date(artdays[index]['article_pushdate']);
                                if (pubtime.getFullYear()===year&&pubtime.getMonth()===mon&&pubtime.getDate()===dayadd-1){
                                    $('.calendar table>tbody>tr:last-child>td:last-child>a').addClass('cal-artpub');
                                    var url='<?php echo Url("index/index/index",["d"=>ddddd]); ?>';
                                    url=url.replace('ddddd',year+""+(mon+1<10?'0'+(mon+1):(mon+1))+(dayadd-1<10?'0'+(dayadd-1):(dayadd-1)));
                                    $('.calendar table>tbody>tr:last-child>td:last-child>a'). attr('href',url);
                                }
                            }

                        }else{
                            $('.calendar table>tbody>tr:last-child').append('<td></td>');
                        }
                    }
                }

            }
            $('#cal-tb').trigger('create');
            $('#cal-foot>tr>td').append("<a class='pre-mon'><<"+(mon===0?12:mon)+"月</a>");
            $('#cal-foot>tr>td').append("<a class='next-mon'>>>"+(mon+2===13?1:mon+2)+"月</a>");



        }
         var tmon=mon;
         var tyear=year;
         $('.calendar').on('click','.pre-mon',function () {
             $('.calendar table>thead>tr>td>a').remove();
             $('.calendar table>tfoot>tr>td>a').remove();
             $('.calendar table>tbody>tr:not(.cal-week)').remove();
             if (--tmon<0){
                 tmon=11;
                 tyear--;
             }
             calShow(tyear,tmon);
         });
         $('.calendar').on('click','.next-mon',function () {
             $('.calendar table>thead>tr>td>a').remove();
             $('.calendar table>tfoot>tr>td>a').remove();
             $('.calendar table>tbody>tr:not(.cal-week)').remove();

             if (++tmon>11){
                 tmon=0;
                 tyear++;
             }
             calShow(tyear,tmon);
         });
        function  isloop(year) {
            if(year%4===0&&year%100!==0||year%400===0){
                return true
            }else{
                return false;
            }
        }
        function  getMondays(year,mon) {
            var day=new Date(year,mon,0);
            return day.getDate();
        }

     })


 </script>
<div class="art-box">
    <div class="artb-title">
        <span>最新文章</span>
        <span>随机推荐</span>
        <span>热门文章</span>
    </div>
    <div class="newest-art display">
        <ul>
            <?php if(is_array($newestArt) || $newestArt instanceof \think\Collection || $newestArt instanceof \think\Paginator): if( count($newestArt)==0 ) : echo "" ;else: foreach($newestArt as $key=>$news): ?>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$news['article_id']]); ?>"><?php echo sub_str($news['article_title'],18); ?></a>
                <a style="display: none" class="tit-dis-no"><?php echo $news['article_title']; ?></a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="random-art hidden">
        <ul>
            <?php if(is_array($randomtArt) || $randomtArt instanceof \think\Collection || $randomtArt instanceof \think\Paginator): if( count($randomtArt)==0 ) : echo "" ;else: foreach($randomtArt as $key=>$random): ?>
            <li>
                <a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$random['article_id']]); ?>"><?php echo sub_str($random['article_title'],18); ?></a>
                    <a style="display: none" class="tit-dis-no"><?php echo $random['article_title']; ?></a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="hot-art hidden">
        <ul>
            <?php if(is_array($hotArt) || $hotArt instanceof \think\Collection || $hotArt instanceof \think\Paginator): if( count($hotArt)==0 ) : echo "" ;else: foreach($hotArt as $key=>$hot): ?>
            <li><a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/detail',['id'=>$hot['article_id']]); ?>"><?php echo sub_str($hot['article_title'],18); ?></a>
                <a style="display: none" class="tit-dis-no"><?php echo $hot['article_title']; ?></a>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>
<script>
    $(function () {

        var i = 0;
        $('.artb-title>span').eq(0).addClass('art-titlehover');
        showArtbox();

        function showArtbox() {
            var d = i % 3;
            $('.artb-title>span').eq(d).addClass('art-titlehover');
            $('.artb-title>span').eq((d + 1) % 3).removeClass('art-titlehover');
            $('.artb-title>span').eq((d + 2) % 3).removeClass('art-titlehover');
            $('.art-box>div:not(.artb-title)').eq(d).removeClass('hidden');
            $('.art-box>div:not(.artb-title)').eq(d).addClass('display');
            $('.art-box>div:not(.artb-title)').eq((d + 1) % 3).addClass('hidden');
            $('.art-box>div:not(.artb-title)').eq((d + 2) % 3).addClass('hidden');
            i++;
            $('.artb-title>span').mouseover(function () {
                clearInterval(inter);
            })
        }

        var inter = setInterval(function () {
            showArtbox();
        }, 2000)

        $('.artb-title>span').each(function (index) {
            $(this).mouseover(function () {
                $('.artb-title>span').eq(index).addClass('art-titlehover');
                $('.artb-title>span').eq((index + 1) % 3).removeClass('art-titlehover');
                $('.artb-title>span').eq((index + 2) % 3).removeClass('art-titlehover');
                $('.art-box>div:not(.artb-title)').eq(index).removeClass('hidden');
                $('.art-box>div:not(.artb-title)').eq(index).addClass('display');
                $('.art-box>div:not(.artb-title)').eq((index + 1) % 3).addClass('hidden');
                $('.art-box>div:not(.artb-title)').eq((index + 2) % 3).addClass('hidden');
            });
        })
        $('.artb-title>span').mouseleave(function () {
            clearInterval(inter);
            inter = setInterval(function () {
                showArtbox();
            }, 2000);

        })
            $('.art-box ul>li').mouseover(function (e) {
                $(this).mousemove(function (e) {
                    var x=e.pageX;
                    var y=e.pageY;
                    var xx=e.screenX;
                    var yy=e.screenY;
                    $(this).after('<span style="color:red" class="tit_alt">'+ $(this).find('.tit-dis-no').text()+'</span>');
                    $(this).parent().find('.tit_alt').css('position','absolute').css('left',x).css('top',y-250)
                })
            });
            $(document).on('mouseleave','.art-box ul>li',function () {
                // $(this).parent
                $(this).parent().find('.tit_alt').remove();
            });
            var length=$('.art-box ul>li').length;
            $('.art-box ul>li').each(function (index) {
               var  li=length/3;
                $($(this).children('a').get(0)).before('<span>'+parseInt(index%li+1)+'</span>');

                    if (parseInt(index%li+1)===1){
                        $(this).children('span').addClass('li-no-one');
                    }else  if (parseInt(index%li+1)===2){
                    $(this).children('span').addClass('li-no-two');
                    }else if (parseInt(index%li+1)===3){
                        $(this).children('span').addClass('li-no-three');
                    } else {
                        $(this).children('span').addClass('li-no-othor');
                    }
            });

    });


</script>
<?php if(($taglist!=null)): ?>
<div class="art-tags">
    <p>标签云集</p>
     <div style="position: relative">
         <?php if(is_array($taglist) || $taglist instanceof \think\Collection || $taglist instanceof \think\Paginator): if( count($taglist)==0 ) : echo "" ;else: foreach($taglist as $key=>$tags): ?>
         <span>
             <a href="<?php if(($webconf['webconf_domain'] !=null)): ?><?php echo $webconf['webconf_domain']; endif; ?><?php echo Url('index/index/index',['tagid'=>$tags['tags_id']]); ?>"><?php echo $tags['tags_content']; ?></a>
             <a style="display: none" class="tags-id"><?php echo $tags['count']; ?></a>
         </span>
         <?php endforeach; endif; else: echo "" ;endif; ?>
     </div>
 </div>
<?php endif; ?>
 <script>
     spans = $('.art-tags>div').find('span');
     for (var i = 0; i < spans.length; i++) {
         var color = Math.random();
         var r = parseInt((color * (i + 1) * 1234) % 254);
         var g = parseInt((color * (i + 1) * 4321) % 254);
         var b = parseInt((color * (i + 1) * 2222) % 254);
         $(spans[i]).css("background-color", "rgba(" + r + "," + g + "," + b + ",0.1)")
         $(spans[i]).css("border", "  1px rgba(" + r + "," + g + "," + b + ",1) solid")
     }


     $(function () {
         $('.art-tags span ').mouseover(function (e) {
             $(this).mousemove(function (e) {
                 var top=$(this).offset().top;
                 var left=$(this).offset().left;
                 var x=e.pageX-left;
                 var y=e.pageY-top;
                 $(this).after('<span style="color:red" class="tit_alt">'+ $(this).find('.tags-id').text()+'个话题</span>');
                 $(this).parent().find('.tit_alt').css('left',x).css('top',y+20)
             })
         });
         $(document).on('mouseleave','.art-tags span ',function () {
             // $(this).parent
             $(this).parent().find('.tit_alt').remove();
         });
     })
 </script>
            
        </div>
        <div class="clear"></div>
    </div>
</div>
<div class="footer">
    
    <div>
    <?php echo $foot; ?>
    <br/>
    <span id="copyright">Copyright © 2017-<span></span></span>
    <span><a href="https://github.com/fank1314"  target="_blank">2016级计算机应用技术 · LeeSlow Fank
    </a> </span>
    <span><a href="http://www.miitbeian.gov.cn/"> <?php echo $webrecord; ?></a></span>
</div>
<script>

    $('#copyright>span').text(new Date().getFullYear())

</script>
    
</div>


<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/prism.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/prism-line-numbers.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/prism-toolbar.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/clipboard.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/timeballs.js"></script>
</body>
</html>