<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:68:"D:\wamp\www\nitrohe_blog/application/admin\view\index\webConfig.html";i:1538127531;s:67:"D:\wamp\www\nitrohe_blog\application\admin\view\baseView\index.html";i:1543641067;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        
<title>网站配置</title>
<div class="webconf">
    <p>网站配置</p>

        <div class="config-main">
            <form id="webconf" method="post">
                <label for="title">站点标题:</label>
                <input class="form-control" type="text" autocomplete="off" name="title" id="title"
                       value="<?php echo $webconf['webconf_title']; ?>">
                <label for="author">网站作者:</label>
                <input class="form-control" type="text" autocomplete="off" name="author" id="author"
                       value="<?php echo $webconf['webconf_author']; ?>">
                <label for="keywords">网站关键字: </label>
                <input class="form-control" type="text" autocomplete="off" name="keywords" id="keywords"
                       value="<?php echo $webconf['webconf_keywords']; ?>">
                <label for="description">网站描述: </label>
                <textarea class="form-control" cols="200" name="description" id="description"><?php echo $webconf['webconf_descriptions']; ?></textarea>
                <label for="record">网站备案:</label>
                <input class="form-control" type="text" autocomplete="off" name="record" id="record"
                       value="<?php echo $webconf['webconf_record']; ?>">
                <label for="domail">网站域名:</label>
                <input class="form-control" type="text" autocomplete="off" name="domail" id="domail"
                       value="<?php echo $webconf['webconf_domain']; ?>">
                <label for="footer">网站底部信息(支持html): </label>
                <textarea class="form-control" cols="200" name="footer" id="footer"><?php echo $webconf['webconf_foothtml']; ?></textarea>
                <label for="domail">上传logo:</label>
                <div class="layui-upload  " style="margin: 10px auto">
                    <button type="button" class="layui-btn" id="test1">上传图片</button>
                    <div class="layui-upload-list imgupload">
                        <img <?php if(($webconf['webconf_logo']!=null)): ?>src="//<?php echo $webconf['webconf_logo']; ?>" <?php endif; ?>class="layui-upload-img" id="logoimg" width="200"
                        style="margin-left: 5px">
                        <p id="demoText"></p>
                        <input style="visibility: hidden" id="logoimgsrc" name="logoimgsrc" value="<?php echo $webconf['webconf_logo']; ?>">
                    </div>
                </div>
                <label for="domail">首页顶部图片:（建议9：1图片）</label>
                <div class="layui-upload  " style="margin: 10px auto">
                    <button type="button" class="layui-btn" id="test2">上传图片</button>
                    <div class="layui-upload-list imgupload">
                        <img <?php if(($webconf['webconf_indextopimg']!=null)): ?>src="//<?php echo $webconf['webconf_indextopimg']; ?>" <?php endif; ?>class="layui-upload-img"
                        id="topimg" width="600"       style="margin-left: 5px">
                        <p id="demoText1"></p>
                        <input style="visibility: hidden" id="topimgsrc" name="topimgsrc" value="<?php echo $webconf['webconf_indextopimg']; ?>">
                    </div>
                </div>
                <label for="page">每页显示</label><input class="form-control" type="text" autocomplete="off" style="width: 50px"
                                                     name="page" id="page" value="<?php echo $webconf['webconf_page']; ?>"> <label>篇文章</label><br/>
                <label for="textcount">首页文章缩略字数：</label><input class="form-control" type="text" autocomplete="off" style="width: 50px"
                                                     name="textcount" id="textcount" value="<?php echo $webconf['webconf_indexartbreco']; ?>"><br/>
                <label>开启评论: <input type="checkbox" width="50" value="1" name="iscomment" id="iscomment"></label>
                <div class="div-btn">
                    <button class="btn saveconf" type="button" id="sava">保存配置</button>
                </div>
            </form>
        </div>

     </div>

</div>
<script>
    window.onload = function () {
        if ("<?php echo $webconf['webconf_iscomment']; ?>" == 1) {
            $('#iscomment').attr('checked', 'checked');

        }
    }
    $('#sava').click(function () {
        var formdate = $('#webconf').serialize();
        $.ajax({
            type: 'post',
            data: formdate,
            dataType: 'json',
            async: true,
            url: '<?php echo Url("admin/index/webConSub"); ?>',
            success: function (data) {
                console.log(data)
                if (JSON.stringify(data)==1){
                    alert_success('提示','保存成功！');

                } else {
                    alert_fail('提示','保存失败');
                }
            },
            error: function () {
                alert_fail('提示','未知错误');

            }


        })

    });


    layui.use('upload', function () {
        var index ;
        var $ = layui.jquery
            , upload = layui.upload;

        //普通图片上传
        var uploadInst = upload.render({
            elem: '#test1'
            , url: '<?php echo Url("admin/Upload/index"); ?>'
            , before: function (obj) {
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {
                    $('#logoimg').attr('src', result); //图片链接（base64）
                });
                index = layer.load(0, {shade: false , offset: '400px'},{time:3000});
            }
            , done: function (res) {
                layer.close(index);
                console.log(res);
                // //如果上传失败
                $('result').text(res.status);
                //    alert(res.status);
                if (res.status) {
                    layer.msg('上传成功', {
                        title:'提示'
                        //不自动关闭
                        ,time:1000
                        ,icon:6
                        , offset: '400px'
                    });
                    $('#logoimgsrc').val(res.cdnurl);
                }
                //上传成功
            }
            , error: function () {
                layer.close(index);
                layer.msg('上传出错：1', {
                    title:'提示'
                    //不自动关闭
                    ,time:1000
                    ,icon:5
                    , offset: '400px'
                });
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });


    });

    layui.use('upload', function () {
        var index ;
        var $ = layui.jquery
            , upload = layui.upload;

        //普通图片上传
        var uploadInst = upload.render({
            elem: '#test2'
            , url: '<?php echo Url("admin/Upload/index"); ?>'
            , before: function (obj) {
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {
                    $('#topimg').attr('src', result); //图片链接（base64）
                });
                index = layer.load(0, {shade: false , offset: '400px'},{time:3000});
            }
            , done: function (res) {
                layer.close(index);
                console.log(res);
                // //如果上传失败
                $('result').text(res.status);
                //    alert(res.status);
                if (res.status) {
                    layer.msg('上传成功', {
                        title:'提示'
                        //不自动关闭
                        ,time:1000
                        ,icon:6
                        , offset: '400px'
                    });
                    $('#topimgsrc').val(res.cdnurl);
                }
                //上传成功
            }
            , error: function () {
                layer.close(index);
                layer.msg('上传出错：1', {
                    title:'提示'
                    //不自动关闭
                    ,time:1000
                    ,icon:5
                    , offset: '400px'
                });
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });


    });
</script>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

