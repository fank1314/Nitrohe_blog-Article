<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:70:"D:\wamp\www\nitrohe_blog/application/admin\view\index\articleEdit.html";i:1538127531;s:67:"D:\wamp\www\nitrohe_blog\application\admin\view\baseView\index.html";i:1543641067;s:77:"D:\wamp\www\nitrohe_blog\application\admin\view\common\articleEdit\index.html";i:1538127531;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        
<title>编辑文章</title>
<script type="text/javascript">
    globalcounter = 1;
    tinymce.init({
        selector: "#mytextarea",
        plugins: [
            "advlist  autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "table contextmenu directionality emoticons textpattern template textcolor paste fullpage  powerpaste toc codesample uploadvideo importcss textcolor colorpicker uploadimage"

        ],
        max_height: 550,
        height: 550,
        convert_urls: false,
        branding: false,
        toolbar1: "undo redo | cut copy paste | bold italic underline strikethrough |" +
        " alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: " searchreplace | bullist numlist | outdent indent blockquote | link unlink anchor uploadimage uploadvideo code |" +
        " inserttime preview | forecolor backcolor  |textpattern",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl |" +
        " spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft  | codesample code  toc  powerpaste",
        menubar: true,
        toolbar_items_size: 'small',
        code_dialog_height: 200,
        code_dialog_width: 300,
        font_formats: "宋体=宋体;微软雅黑=微软雅黑;新宋体=新宋体;微软雅黑='微软雅黑';黑体='黑体';仿宋='仿宋';楷体='楷体';隶书='隶书';幼圆='幼圆';" +
        "Arial='Arial';Times New Roman='Times New Roman'",
        automatic_uploads: true,
        uploadimage_url: "<?php echo Url('admin/Upload/index'); ?>",
        uploadvideo_url: "<?php echo Url('admin/Upload/indexvideo'); ?>",
        content_css : "/nitrohe_blog/public/static/css/tinymce.css",
        codesample_languages: [
            {text: 'HTML/XML', value: 'markup'},
            {text: 'JavaScript', value: 'javascript'},
            {text: 'CSS', value: 'css'},
            {text: 'PHP', value: 'php'},
            {text: 'Ruby', value: 'ruby'},
            {text: 'Python', value: 'python'},
            {text: 'Java', value: 'java'},
            {text: 'C', value: 'c'},
            {text: 'C#', value: 'csharp'},
            {text: 'C++', value: 'cpp'}
        ],
        codesample_content_css:"/nitrohe_blog/public/static/css/prism.css",
        textcolor_map: [
            "000000", "Black",
            "993300", "Burnt orange",
            "333300", "Dark olive",
            "003300", "Dark green",
            "003366", "Dark azure",
            "000080", "Navy Blue",
            "333399", "Indigo",
            "333333", "Very dark gray",
            "800000", "Maroon",
            "FF6600", "Orange",
            "808000", "Olive",
            "008000", "Green",
            "008080", "Teal",
            "0000FF", "Blue",
            "666699", "Grayish blue",
            "808080", "Gray",
            "FF0000", "Red",
            "FF9900", "Amber",
            "99CC00", "Yellow green",
            "339966", "Sea green",
            "33CCCC", "Turquoise",
            "3366FF", "Royal blue",
            "800080", "Purple",
            "999999", "Medium gray",
            "FF00FF", "Magenta",
            "FFCC00", "Gold",
            "FFFF00", "Yellow",
            "00FF00", "Lime",
            "00FFFF", "Aqua",
            "00CCFF", "Sky blue",
            "993366", "Red violet",
            "FFFFFF", "White",
            "FF99CC", "Pink",
            "FFCC99", "Peach",
            "FFFF99", "Light yellow",
            "CCFFCC", "Pale green",
            "CCFFFF", "Pale cyan",
            "99CCFF", "Light sky blue",
            "CC99FF", "Plum"
        ],
        language: 'zh_CN',
        powerpaste_word_import: 'propmt',// 参数可以是propmt, merge, clear，效果自行切换对比
        powerpaste_html_import: 'propmt',// propmt, merge, clear
        powerpaste_allow_local_images: true,
        paste_data_images: true,
        paste_preprocess:function (plugin,args) {
            function load(src){
               loadImageToBlob(src, function(blobFile) {
		       var x = new XMLHttpRequest();
                   x.onreadystatechange = function(){
                       if( this.readyState == 4 && this.status == 200 ){
                           data = this.responseText;
                           console.log('response data: ' + data);
                       }
                   };
                   x.open('POST', '<?php echo Url("Admin/Upload/uploadPasteImg"); ?>');
                   x.send(blobFile);
                });


            }


        },
        images_upload_handler: function (blobInfo, success, failure) {
             var blob= blobInfo.blob();
           var xhr,formdata;
           xhr=new XMLHttpRequest();
           xhr.withCredentials=false;
            xhr.open('post','<?php echo Url("Admin/Upload/index"); ?>');
            xhr.onload = function() {
                var json;
                if (xhr.status != 200) {
                    failure('HTTP Error: ' + xhr.status);
                    return;
                }

                json = JSON.parse(xhr.responseText);

                if (!json || typeof json.cdnurl != 'string') {
                    failure('Invalid JSON: ' + xhr.responseText);
                    return;
                }

                success('//'+json.cdnurl);
            };
                formData = new FormData();
                formData.append('file', blobInfo.blob(), blobInfo.filename());

                xhr.send(formData);





        }

    });

</script>
<div class="art-main">
    <div class="art-content">
        <div class="articleinfo">
            <p>编辑文章</p>
            <input type="text" name="title" placeholder="键入标题" value=<?php echo $article['article_title']; ?> class="form-control"
                   id="art-title">
            <label for="art-author">作者：</label><input type="text" id="art-author" name="author"
                                                      value=<?php echo $article['article_author']; ?> class="form-control"
                                                      placeholder="请输入作者">
        </div>
        <div class="textareas">
            <textarea id="mytextarea" name="article">
            </textarea>
        </div>

        <div style="display:none;">
            <form id="form-articlePreview" method="post" target="_blank" action="<?php echo Url('index/index/articlePreview'); ?>">
                <input type="hidden" name="title" id="artpre-title">
                <input type="hidden" name="author" id="artpre-author">
                <input type="hidden" name="content" id="artpre-content">
                <input type="hidden" name="type" id="artpre-type">
            </form>
        </div>

        <div class="art-comment">
            <button class="btn add-comment">添加评论</button>
            <div class="comment-input" style="display: none;">
                <div>
                    <div><span>评论</span></div>
                </div>
                <div>
                <textarea class="comm-content" rows="5" cols="80">

                </textarea>
                </div>
                <div class="comment-user">
                    <div>
                        <button class="btn comment-btn">提交评论</button>
                    </div>
                </div>

            </div>
            <table class="table table-hover comm-list">
                <?php if(is_array($artcomment) || $artcomment instanceof \think\Collection || $artcomment instanceof \think\Paginator): if( count($artcomment)==0 ) : echo "" ;else: foreach($artcomment as $key=>$comm): ?>
                <tr style="background-color: rgba(232,237,234,0.5)">
                    <td>
                        <div><img src="<?php echo $comm['comment_headimg']; ?>"><span class="comm-name"><?php echo $comm['comment_user']; ?></span>
                        </div>
                        <div class="comm-time"><?php echo $comm['comment_date']; ?></div>
                        <div>回复给文章</div>
                    </td>
                    <td><?php echo $comm['comment_content']; ?></td>
                    <td>
                        <button class="btn reply">回复</button>
                        <button class="btn del">删除</button>

                    </td>
                    <td style="display: none" class="comm-id"><?php echo $comm['comment_id']; ?></td>
                </tr>
                <?php if(is_array($comm['comment_reply']) || $comm['comment_reply'] instanceof \think\Collection || $comm['comment_reply'] instanceof \think\Paginator): if( count($comm['comment_reply'])==0 ) : echo "" ;else: foreach($comm['comment_reply'] as $key=>$reply): ?>
                <tr>
                    <td>
                        <div><img src="<?php echo $reply['comment_headimg']; ?>"><span class="comm-name"><?php echo $reply['comment_user']; ?></span>
                        </div>
                        <div class="comm-time"><?php echo $reply['comment_date']; ?></div>
                        <div>回复给<?php echo $reply['comment_user']; ?></div>
                    </td>
                    <td><?php echo $reply['comment_content']; ?></td>
                    <td>
                        <button class="btn reply">回复</button>
                        <button class="btn del">删除</button>

                    </td>
                    <td style="display: none" class="comm-id"><?php echo $comm['comment_id']; ?></td>

                </tr>
                <?php endforeach; endif; else: echo "" ;endif; endforeach; endif; else: echo "" ;endif; ?>
            </table>
        </div>
    </div>
    <div class="art-pub-rightsider">
        <div class="choosetags">
    <p>文章标签</p>
    <div class="choosed">
        <?php if(is_array($arttags) || $arttags instanceof \think\Collection || $arttags instanceof \think\Paginator): if( count($arttags)==0 ) : echo "" ;else: foreach($arttags as $key=>$arttags): ?>
        <span><?php echo $arttags['tags_content']; ?><span class="tags-id" style="display: none"><?php echo $arttags['tags_id']; ?></span><a>×</a></span>

        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div></div>
    <div class="tags">
        <?php if(is_array($tags) || $tags instanceof \think\Collection || $tags instanceof \think\Paginator): if( count($tags)==0 ) : echo "" ;else: foreach($tags as $key=>$tags): ?>
        <span><?php echo $tags['tags_content']; ?><span class="tags-id" style="display: none"><?php echo $tags['tags_id']; ?></span></span>

        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div>
<div class="articletyle">
    <p>文章分类</p>
    <label>请选择文章分类:</label>
    <div class="select">
        <select class="selectpicker" id="sel-type" data-live-search="true">
            <?php if(is_array($types) || $types instanceof \think\Collection || $types instanceof \think\Paginator): if( count($types)==0 ) : echo "" ;else: foreach($types as $key=>$types): ?>
            <option style="font-weight: bold;color: black" value="-<?php echo $types['menu_id']; ?>"><?php echo $types['menu_name']; ?></option>
            <?php if(is_array($types['subtype']) || $types['subtype'] instanceof \think\Collection || $types['subtype'] instanceof \think\Paginator): if( count($types['subtype'])==0 ) : echo "" ;else: foreach($types['subtype'] as $key=>$sutypes): ?>
            <option style="color: #777" value="<?php echo $sutypes['types_id']; ?>"><?php echo $sutypes['types_content']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; endforeach; endif; else: echo "" ;endif; ?>
        </select>
    </div>

</div>
<div class="articleimg">
    <p>缩略图</p>
    <div class="selimg">

        <div class="layui-upload ">
            <button type="button" class="layui-btn" id="test1">上传图片</button>
            <div class="layui-upload-list imgupload">
                <img class="layui-upload-img" <?php if(($article['article_imgSrc'] !=null )): ?>src="//<?php echo $article['article_imgSrc']; ?>" <?php endif; ?>id="breimg" width="270" style="margin-left: 5px">
                <p id="demoText"></p>
                <input style="visibility: hidden" id="imgsrc" name="Img" value=""/>
            </div>
        </div>

    </div>
</div>
<div class="published">
    <p>文章发布</p>
    <div>
        <span style="text-space: 0">当前状态:
        <?php if(($article['article_status']==0)): ?>
            草稿
            <?php endif; if(($article['article_status']==1)): ?>
            已发布
            <?php endif; ?>
        </span>
        <button class="btn" id="articlePreview">文章预览</button>
    </div>
    <div></div>
    <a><i class="iconfont">&#xe606;</i> 公开度：<span id="published-public">公开</span></a>&nbsp;<a id="edit">编辑</a>
    <div id="ispublic">
        <form id="ispublic-form" method="post">
        <span><input class="form-control ispublic-radio"  id="public" type="radio" name="isPublic" value="1"><label
                for="public">公开</label></span>
            <span> <input class="form-control" id="hometop" type="checkbox" value="2"><label
                    for="hometop">将文章置于首页顶端</label></span>
            <span> <input class="form-control ispublic-radio" id="passw" name="isPublic" value="-1" type="radio"><label
                    for="passw">密码保护</label></span>
            <span> 密码:<input class="form-control" type="text" id="passw-content"><span></span></span>
            <span> <input class="form-control ispublic-radio" id="secret" name="isPublic" value="0" type="radio"><label
                    for="secret">私密</label></span>
            <div id="btns0" style="display: block">
                <button class="btn" id="btn-ispublic-sure">确定</button>
                <button class="btn">取消</button>
            </div>
        </form>
    </div>
    <div></div>
    <div>
        <span><input type="checkbox" class="form-control" checked="checked" id="is-comment"> <label for="is-comment">是否可以评论</label></span>
    </div>

    <div></div>
    <div id="btns1">
        <a href="#">取消</a>
        <button class="btn">移至回收站</button>
        <?php if(($article['article_status']==0)): ?>
        <button class="btn" id="published-save">保存</button>
        <button class="btn" id="published-pub">发布</button>
        <?php endif; if(($article['article_status']==1)): ?>
        <button class="btn" id="published-update">更新</button>
        <?php endif; ?>
    </div>
</div>
<div class="end"></div>
<script>

    $(function () {
        $('.selectpicker').selectpicker({
            noneSelectedText: '请选择类别',
            title:"请选择类别"
        });
    });
    var ispublic='<?php echo $article['article_public']; ?>';
    $('#sel-type').val('<?php echo $article['article_typeid']; ?>');
    $('.ispublic-radio').each(function (index) {
        ispublic==2?1:ispublic;
        if ($(this).val()==ispublic){
            $(this).attr("checked", "checked");
        }
    })
    if (ispublic==2){
        $('#hometop').attr('checked','checked');
    }else if(ispublic==-1){
        $('#passw-content').val('<?php echo $article['article_password']; ?>');
        $('#published-public').text('密码保护')
    }else if(ispublic==0){
        $('#published-public').text('私密');

    }
    if ('<?php echo $article['article_iscomment']; ?>'==1){
        $('#is-comment').attr('checked','checked');
    }

    spans = $('.choosetags').find('span');
    for (var i = 0; i < spans.length; i++) {
        var color = Math.random();
        var r = parseInt((color * (i + 1) * 1234) % 254);
        var g = parseInt((color * (i + 1) * 4321) % 254);
        var b = parseInt((color * (i + 1) * 2222) % 254);
        $(spans[i]).css("background-color", "rgba(" + r + "," + g + "," + b + ",0.1)");
        $(spans[i]).css("border", "  1px rgba(" + r + "," + g + "," + b + ",1) solid") ;

    }
    $('.choosed').on('click','a',function () {
        $(this).parent().remove();
    })
    // tags = $('.tags>span');
    // for (var i = 0; i < tags.length; i++) {
    $('.tags>span').click(function () {
        var flag = 0, choosed = $('.choosed>span');
        // var obj=$(choosed[0]).clone();
        // obj.find('a').remove();
        // alert(choosed.length)
        // alert(obj.text()+","+ $(this).text())
        for (var i = 0; i < choosed.length; i++) {
            var obj = $(choosed[i]).clone();
            obj.find('a').remove();
            // console.log("a"+obj.text());
            // console.log("this"+$(this).text());
            if (obj.text() == $(this).text()) {
                flag = 1;
            }
        }
        if (!flag) {
            var choosed = $('.choosed');
            var add = $('<span></span>');
            var tagschoosed = $(this).clone();
            // tagschoosed.find('span').remove()
            //  console.log(tagschoosed.html())
            tagschoosed.html($(this).html() + '<a>×</a>').appendTo(choosed);
            // console.log(choosed.html())
        }


        // }
    })
    var status1 = 0;
    $('#edit').click(function () {
        console.log(status1)
        if (status1 == 0) {
            $('#ispublic').css("display", "block");
            status1 = 1;
        } else if (status1 == 1) {
            $('#ispublic').css("display", "none");
            $('#passw-content+span').text('')
            status1 = 0;
        }


    })
    var status2 = status3 = 0;
    $($('#ispublic-form').children()[0]).click(function () {
        if (status1 == 1) {
            $($('#ispublic-form').children()[1]).css('display', 'block');
            $($('#ispublic-form').children()[3]).css('display', 'none');
        }
    })
    $($('#ispublic-form').children()[2]).click(function () {
        if (status1 == 1) {
            $($('#ispublic-form').children()[3]).css('display', 'block');
            $($('#ispublic-form').children()[1]).css('display', 'none');
        }
    });
    // $($('#btns0').children()[0]).click(function () {
    //     if (status1 == 1) {
    //         $('#ispublic-form').css("display", "none");
    //         status1 = 0;
    //     }
    // });
    $($('#btns0').children()[1]).click(function () {
        if (status1 == 1) {
            $('#ispublic').css("display", "none");
            status1 = 0;

            return false;
        }
    });

    layui.use('upload', function () {
        var index ;
        var $ = layui.jquery
            , upload = layui.upload;

        //普通图片上传
        var uploadInst = upload.render({
            elem: '#test1'
            , url: '<?php echo Url("admin/Upload/index"); ?>'
            , before: function (obj) {
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {
                    $('#breimg').attr('src', result); //图片链接（base64）
                });
                index = layer.load(0, {shade: false , offset: '400px'},{time:3000});
            }
            , done: function (res) {
                layer.close(index);
                console.log(res);
                // //如果上传失败
                $('result').text(res.status);
                //    alert(res.status);
                if (res.status) {
                    layer.msg('上传成功', {
                        title:'提示'
                        //不自动关闭
                        ,time:1000
                        ,icon:6
                        , offset: '400px'
                    });
                    $('#imgsrc').val(res.cdnurl);
                }
                //上传成功
            }
            , error: function () {
                layer.close(index);
                layer.msg('上传出错：1', {
                    title:'提示'
                    //不自动关闭
                    ,time:1000
                    ,icon:5
                    , offset: '400px'
                });
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });


    });


    $('#btn-ispublic-sure').click(function () {
        if (($('#passw-content').val() == null || $('#passw-content').val() == '') && $('#ispublic-form .ispublic-radio:checked').val() == -1) {
            $('#passw-content+span').text('密码不能为空').css('color', 'red')

        } else if (status1 == 1) {
            $('#ispublic').css("display", "none");
            // console.log("ispublic"+$('#ispublic-form .ispublic-radio:checked').val());
            // $('#is-public-res').val($('#ispublic-form .ispublic-radio:checked').val());
            $('#published-public').text($('#ispublic-form .ispublic-radio:checked+label').text());
            // if ($('#ispublic-form .ispublic-radio:checked').val() == 1) {
            //     // $('#hometop').click(function () {
            //     if ($('#hometop').prop('checked')) {
            //         $('#is-public-res').val('2');
            //
            //     }
            //     // })
            //
            // } else if ($('#ispublic-form .ispublic-radio:checked').val() == -1) {
            //     $('#is-public-pass').val($('#passw-content').val());
            // }

            status1 = 0;
        }
// console.log( "isp"+$('#is-public-res').val());
// console.log(  $('#is-public-pass').val());
        return false;
    })
    
    $('#published-update,#published-save,#published-pub').click(function () {
        var btntype;
        if ($(this).attr('id')=='published-update'){
            btntype=1;
        } else if($(this).attr('id')=='published-save'){
            btntype=2;
        }else if($(this).attr('id')=='published-pub'){
            btntype=3;
        }
        if (tinyMCE.activeEditor.getContent().replace(new RegExp('\n','g'),'')=='<!DOCTYPE html><html><head></head><body></body></html>'){
            alert_fail('提示','文章不可为空！')
            return false;
        }
        if ($('#art-author').val()==null||$.trim($('#art-author').val())==''||
            $('#art-title').val()==null||$.trim($('#art-title').val())=='' ){
            alert_fail('提示','标题或作者不可为空！')
            return false;
        }
        // console.log($('#ispublic-form .ispublic-radio:checked').val())
        var tagsId = new Array();
        var publishTemp=1;
        var passw=0;

        var data = $('.choosed>span>span');
        console.log($('.choosed').html())
        for (var i = 0; i < data.length; i++) {
            // console.log(data.eq(i).text())
            tagsId[i] = data.eq(i).text();
        }
        var typeid = $('.articletyle select').val()
        // console.log(typeid)
        $('#type-id').val(typeid);
        publishTemp=$('#ispublic-form .ispublic-radio:checked').val();
        if ($('#ispublic-form .ispublic-radio:checked').val() == 1) {
            // $('#hometop').click(function () {
            if ($('#hometop').prop('checked')) {
                publishTemp=2;

            }
            // })

        } else if ($('#ispublic-form .ispublic-radio:checked').val() == -1) {
            passw=$('#passw-content').val();
        }
        var iscomment=0;
        if ($('#is-comment').prop('checked')) {
            iscomment=1;

        }
        var title=$('#art-title').val();
        var author=$('#art-author').val();
        var articleContent=tinyMCE.activeEditor.getContent();
        var  tags= tagsId;
        // var  tags=JSON.stringify(tagsId);
        var type=typeid;
        var imgSrc=$('#imgsrc').val();
        var published=publishTemp==undefined?1:publishTemp;
        var  password=passw;
        var request=new Object();
        request=GetRequest();
        var artid=request['artid'];
        // //
        // console.log('title\t'+title)
        // console.log('author\t'+author)
        // // console.log('articleContent\t'+articleContent)
        console.log('tags\t'+tags)
        // console.log('type\t'+type)
        // console.log('img\t'+imgSrc)
        // console.log('published\t'+published)
        // console.log('password\t'+password)
        if (btntype==1){
            artAjax('<?php echo Url("admin/index/artUpdate"); ?>',
                {'data':JSON.stringify({artid:artid,title:title,author:author,articleContent:articleContent,
                        tags:tags,type:type,imgSrc:imgSrc,published:published,password:password,iscomment:iscomment})},
                        function () {
                alert_success('提示','更新成功');
            })
        } else if (btntype==2){
            artAjax('<?php echo Url("admin/index/artDraftSave"); ?>',
                {'data':JSON.stringify({artid:artid,title:title,author:author,articleContent:articleContent,
                        tags:tags,type:type,imgSrc:imgSrc,published:published,password:password,iscomment:iscomment})},
                function () {
                alert_success('提示','保存成功');
            })
        } else if (btntype==3){
            artAjax('<?php echo Url("admin/index/artDraftPublish"); ?>',
                {'data':JSON.stringify({artid:artid,title:title,author:author,articleContent:articleContent,
                        tags:tags,type:type,imgSrc:imgSrc,published:published,password:password,iscomment:iscomment})},
                function () {
                alert_success('提示','发布成功');
            })
        }
        function artAjax(url,data,tip){
            $.ajax({
                type:'post',
                data:data,
                dataType:'json',
                async:true,
                url:url,
                success:function (data) {
                    // alert(JSON.stringify(data))
                    console.log(JSON.stringify(data))
                    if (JSON.stringify(data)==1){
                        // alert_success('提示','发布成功');
                        tip();


                    }else{
                          alert_fail('提示', '错误1');

                    }


                },
                error:function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert('错误-2');
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                    alert_fail('提示','未知错误')
                }

            })
        }




    })
    $('#articlePreview').click(function () {
        var title = $('#art-title').val();
        var author = $('#art-author').val();
        var articleContent = tinyMCE.activeEditor.getContent();
        var type = $('.articletyle select:selected').text();
        $('#artpre-title').val(title);
        $('#artpre-author').val(author);
        $('#artpre-content').val(articleContent);
        $('#artpre-type').val(type);

        $('#form-articlePreview').submit();
        window.alert=function () {
            return false;
        };
    })

</script>

    </div>
    <div style="clear: both"></div>
</div>

<div></div>
<script>
    var html = '<?php echo $htmlcontent; ?>';
    // console.log(html);
    window.onload = function () {
        tinyMCE.activeEditor.setContent(html);
    }
    $('.add-comment').click(function () {
        console.log($(this).next().attr('style'));
        if ($(this).next().attr('style') == 'display: none;') {
            $(this).next().css('display', 'block');

        } else {
            $(this).next().css('display', 'none');

        }
    })

    var $comment_input = '        <tr class="tr-comm-input"  style="height: 200px" >\n' +
        '                    <td colspan="3" >\n' +
        '                        <div class="comment-input">\n' +
        '                            <div style="display: none">\n' +
        '                                <div><span></span></div>\n' +
        '                            </div>\n' +
        '                            <div>\n' +
        '                                        <textarea class="comm-content"  rows="5" cols="80">\n' +
        '\n' +
        '                                       </textarea>\n' +
        '                            </div>\n' +
        '                            <div class="comment-user" style="width: 100%">\n' +
        '\n' +
        '                                <div>\n' +
        '                                    <button class="btn comment-btn">提交评论</button>\n' +
        '                                </div>\n' +
        '                            </div>\n' +
        '\n' +
        '                        </div>\n' +
        '                    </td>\n' +
        '                </tr>\n' +
        '                ';
    comment_input = $.parseHTML($comment_input);
    $('.comm-list').on('click', '.reply', function () {
        console.log($(this).parent().parent().next().attr('class'))
        if ($(this).parent().parent().next().attr('class') != 'tr-comm-input') {
            $(this).parent().parent().after(comment_input);
        } else {
            $(this).parent().parent().next().remove();

        }
    })

    $('.art-comment').on('click', '.comment-btn', function () {
        // console.log($(this).parent().parent().parent().prev().attr('class'))

        // console.log("artid:"+artid);
        // console.log("username:"+username);
        // console.log("qq:"+qq);
        // console.log("content:"+commentext);
        var commid = <?php echo $commlastid; ?> + 1;
        // console.log('lastid:'+commid);
        var Request = new Object();
        Request = GetRequest();
        var artId = Request['artid'];
        var commentext = $(this).parent().parent().parent().find('textarea').val()
        var username = '作者:';
        var qq = '00000000';
        var curtime = formatDate(new Date().getTime());
        var addcom = null;
        var info = null;
        var replyId = null;
        var index = null;
        var commthis = null;
        var parentUsername = null;
        var headImgUrl = "/nitrohe_blog/public/static/headimg/" + Math.ceil(Math.random() * 10) + ".jpg";
        if ($(this).parent().parent().parent().prev().attr('class') == 'btn add-comment') {
            replyId = -1;
            info = '      <tr style="background-color: rgba(232,237,234,0.5)">\n' +
                '                    <td>\n' +
                '                        <div><img src="<?php echo $comm['comment_headimg']; ?>"><span class="comm-name">' + username + '</span>\n' +
                '                        </div>\n' +
                '                        <div class="comm-time">' + curtime + '</div>\n' +
                '                        <div>回复给文章</div>\n' +
                '                    </td>\n' +
                '                    <td>' + commentext + '</td>\n' +
                '                    <td>\n' +
                '                        <button class="btn reply">回复</button>\n' +
                '                        <button class="btn del">删除</button>\n' +
                '\n' +
                '                    </td>\n' +
                ' <td style="display: none" class="comm-id">' + commid + '</td>' +
                '                </tr>'
            addcom = $('.comm-list');
            commthis = $(this).parent().parent().parent();
            commid++;
            commAjax({
                'data': JSON.stringify({
                    commenttext: commentext,
                    username: username,
                    qq: qq,
                    artId: artId,
                    comment_parent: replyId,
                    headimgUrl: headImgUrl
                })
            }, 1, addcom, info, commthis);
        } else {
            parentUsername = $(this).parent().parent().parent().parent().parent().prev().find('.comm-name').text();
            replyId = $(this).parent().parent().parent().parent().parent().prev().find('.comm-id').text();
            info = '  <tr>\n' +
                '                    <td>\n' +
                '                        <div><img src="<?php echo $reply['comment_headimg']; ?>"><span class="comm-name">' + username + '</span>\n' +
                '                        </div>\n' +
                '                        <div class="comm-time">' + curtime + '</div>\n' +
                '                        <div>回复给 ' + parentUsername + '</div>\n' +
                '                    </td>\n' +
                '                    <td>' + commentext + '</td>\n' +
                '                    <td>\n' +
                '                        <button class="btn reply">回复</button>\n' +
                '                        <button class="btn del">删除</button>\n' +
                '\n' +
                '                    </td>\n' +
                '               <td style="display: none" class="comm-id">' + commid + '</td>' +
                '                </tr>';
            // console.log(replyId);
            commthis = addcom = $(this).parent().parent().parent().parent().parent();
            commid++;
            commAjax({
                'data': JSON.stringify({
                    commenttext: commentext,
                    username: username,
                    qq: qq,
                    artId: artId,
                    comment_parent: replyId,
                    headimgUrl: headImgUrl
                })
            }, 2, addcom, info, commthis);
        }
    })

    function commAjax(data, type, addcom, info, commthis) {
        $.ajax({
            type: 'post',
            data: data,
            dataType: 'json',
            url: "<?php echo Url('index/index/addComment'); ?>",
            success: function (data) {
                console.log("com" + JSON.stringify(data));

                var html = $.parseHTML(info);

                alert_success('提示', '回复成功');
                setTimeout(function () {
                    $('.comm-content').val('');
                    $('.qq').val('');
                    $('.username').val('');
                    type === 1 ? addcom.append(html) : addcom.after(html);
                    commthis.remove();
                }, 2000);
            },
            error: function () {
                alert_fail('提示', '未知错误')
            }


        });

    }

    $('.comm-list').on('click', '.del', function () {
        var commid = $(this).parent().next().text();
        alert_ask('确定要删除此评论(所有回复评论也将会全部删除)?', function () {
            $.ajax({
                type: 'post',
                dataType: 'json',
                data: {'data': JSON.stringify({commid: commid})},
                url: '<?php echo Url("admin/index/delComment"); ?>',
                success: function (data) {
                    console.log(data);
                    var url = window.location.href;
                    alert_success_url('提示', '删除成功', url);
                },
                error: function () {
                    alert_fail('提示', '未知错误')
                }
            })
        })


    });
</script>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

