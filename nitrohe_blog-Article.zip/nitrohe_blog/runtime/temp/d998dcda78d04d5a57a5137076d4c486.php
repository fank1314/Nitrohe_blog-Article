<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:65:"D:\wamp\www\nitrohe_blog/application/admin\view\index\menuMg.html";i:1538127531;s:67:"D:\wamp\www\nitrohe_blog\application\admin\view\baseView\index.html";i:1543641067;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        

<title>菜单管理</title>
<script>
    window.onload = function () {
        $("#menucheck").click(function () {
            if ($(this).is(':checked')) {
                menuEdit();

            } else {
                $('div.menu ul>li>div span:nth-child(2)').css('display', 'none');
                $(function () {
                    $('.sortable').sortable('destroy')
                })

            }
        })

        function menuEdit() {
            $('div.menu ul>li>div span:nth-child(1)').css('cursor', 'text');
            $('div.menu ul>li>div span:nth-child(2)').css('display', 'inline-block');
            var index = new Array();
            // index[0]=new Array();
            // index[1]=new Array();
            $(function () {
                $('.sortable').sortable({
                    cursor: 'move',
                    items: '.sorts',
                    // start: function () {
                    //     for (var i = 0; i < $('.sorts').length; i++) {
                    //
                    //         var indextext = $('.sorts').children('#menuIndex').eq(i).text();
                    //         console.log("start:"+$('.sorts').children('#menuIndex').eq(i).text());
                    //         index[0][i] = indextext;
                    //     }
                    // },
                    update: function (event, ui) {

                        for (var i = 0; i < $('.sorts').length; i++) {

                            var indextext = $('.sorts').children('#menuVal').eq(i).text();
                            console.log("update:" + $('.sorts').children('#menuVal').eq(i).text());
                            index[i] = indextext;
                        }
                        //
                        // index=JSON.stringify(index);
                        console.log(index)
                        // indexjs=index.replace(/\\/g,"");
                        // $('#menuli').val(index);
                        // console.log($('#menuli').val());
                        // formdata = $('#menuliform').serialize();
                        $.ajax({
                            type: 'post',
                            data: {'index': JSON.stringify({update: index})},
                            url: "<?php echo Url('admin/index/menuUpdateindex'); ?>",
                            dataType: 'json',
                            async: true,
                            success: function (data) {
                                console.log("success" + JSON.stringify(data))
                            }

                        })

                    },
                }).disableSelection();
            })


            //修改菜单名字
            $('div.menu>ul>li>div span:nth-child(1)').click(function () {
                $a = $(this).parent().parent();
                $val = $a.children('#menuVal').text();
                var menuName=$(this).text();
                var index = layer.open({
                    title: ['修改菜单名', 'font-size:16px'],
                    type: 1,
                    closeBtn: 2,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['320px', '200px'], //宽高
                    content: '<form id="menuform" method="post"> ' +
                    '<input type="text" id="menuinput" name="menuinput"  class="form-control addinput">' +
                    '<input type="text" id="menu-id" name="menuid" style="display: none">' +
                    '<span id="tips"></span></form>' +
                    '<button class="btn addbtn" type="button" id="menubtnsure">添加</button> ' +
                    '<button class="btn  addbtncal" id="menubtncal">取消</button>'
                })
                    $("#menuinput").val(menuName);
                $('#menubtnsure').click(function () {
                    if ($('#menuinput').val() == null || $('#menuinput').val().length < 1) {
                        $('#tips').html("菜单名不能为空")
                    } else {
                        $('#menu-id').val($val);
                        var formdata = $('#menuform').serialize();
                        $.ajax({
                            type: "post",
                            data: formdata,
                            async: true,
                            url: "<?php echo Url('admin/index/updateMenuName'); ?>",
                            dataType: 'json',
                            success: function (response) {
                                // alert(JSON.stringify(response.error))
                                // console.log(response)
                                if (response == null || response == 'undefined') {
                                    alert_fail('提示', '错误1');
                                } else {
                                    if (JSON.stringify(response.v) == '1') {
                                        alert_success_url('提示', '修改成功', "<?php echo Url('admin/index/menuMg'); ?>");

                                    } else {
                                        alert_fail('提示', '修改失败');

                                    }
                                }
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                alert_fail('提示', '错误-1');

                                // alert(XMLHttpRequest.status);
                                // alert(XMLHttpRequest.readyState);
                                // alert(textStatus);
                            }


                        })
                    }


                })
                $('#menubtncal').click(function () {
                    layer.close(layer.index)
                })

            })
            //修改类别名字
            $('div.menu>ul>li>ul>li>div span:nth-child(1)').click(function () {
                $a = $(this).parent().parent();
                $val = $a.children('#typeVal').text();
                var typeName=$(this).text();
                var index = layer.open({
                    title: ['修改类别名', 'font-size:16px'],
                    type: 1,
                    closeBtn: 2,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['320px', '200px'], //宽高
                    content: '<form id="menuform" method="post"> ' +
                    '<input type="text" id="typeinput" name="typeinput" class="form-control addinput">' +
                    '<input type="text" id="type-id" name="typeid" style="display: none">' +
                    '<span id="tips"></span></form>' +
                    '<button class="btn addbtn" type="button" id="menubtnsure">添加</button> ' +
                    '<button class="btn  addbtncal" id="addmenubtncal">取消</button>'
                })
                $("#typeinput").val(typeName    );
                $('#menubtnsure').click(function () {
                    if ($('#typeinput').val() == null || $('#typeinput').val().length < 1) {
                        $('#tips').html("类别名不能为空")
                    } else {
                        $('#type-id').val($val);
                        var formdata = $('#menuform').serialize();
                        $.ajax({
                            type: "post",
                            data: formdata,
                            async: true,
                            url: "<?php echo Url('admin/index/updateTypeName'); ?>",
                            dataType: 'json',
                            success: function (response) {
                                // alert(JSON.stringify(response.error))
                                // console.log(response)
                                if (response == null || response == 'undefined') {
                                    alert_fail('提示', '错误1');
                                } else {
                                    if (JSON.stringify(response.v) == '1') {
                                        alert_success_url('提示', '修改成功', "<?php echo Url('admin/index/menuMg'); ?>");

                                    } else {
                                        alert_fail('提示', '修改失败');

                                    }
                                }
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                alert_fail('提示', '错误-1');

                                // alert(XMLHttpRequest.status);
                                // alert(XMLHttpRequest.readyState);
                                // alert(textStatus);
                            }


                        })
                    }


                })
                $('#menubtncal').click(function () {
                    layer.close(layer.index)
                })

            })
        }


    }


</script>
<div class="menu">
    <p>添加菜单和子菜单（类别）</p>
    <span> <input id="menucheck" type="checkbox"><label
            for="menucheck">编辑菜单</label></span>
    <span>首页</span>
    <ul class="sortable">

        <?php if($menu != null): if(is_array($homemenu) || $homemenu instanceof \think\Collection || $homemenu instanceof \think\Paginator): if( count($homemenu)==0 ) : echo "" ;else: foreach($homemenu as $key=>$homemenu): ?>
        <li class="sorts">
            <div>
                <span><?php echo $homemenu['menu_name']; ?></span>
                <span style="display: none">×</span>
            </div>
            <span id="menuVal" style="display: none"><?php echo $homemenu['menu_id']; ?></span>
            <ul>

                <?php if(is_array($homemenu['submenu']) || $homemenu['submenu'] instanceof \think\Collection || $homemenu['submenu'] instanceof \think\Paginator): if( count($homemenu['submenu'])==0 ) : echo "" ;else: foreach($homemenu['submenu'] as $key=>$submenu): ?>
                <li>
                    <div>
                        <span><?php echo $submenu['types_content']; ?></span>
                        <span style="display: none">×</span>
                    </div>
                    <span id="typeVal" style="display: none"><?php echo $submenu['types_id']; ?></span>

                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>

                <li class="addtypebtn <?php echo $homemenu['menu_id']; ?>"><i class="iconfont">&#xe613;</i></li>

            </ul>

        </li>
        <?php endforeach; endif; else: echo "" ;endif; endif; if($menuCount <= 9): ?>
        <li id="addmenubtn"><i class="iconfont">&#xe613;</i></li>
        <?php endif; ?>
    </ul>
    <div style="display:none;">
        <form id="menuliform" method="post">
            <input name="menuli" id="menuli" class="text">
        </form>
    </div>
    <div style="display:none;">
        <form id="typeliform" method="post">
            <input name="typeli" id="typeli" class="text">
        </form>
    </div>

</div>
<script>


    // 添加菜单
    $('#addmenubtn').click(function () {
        var index = layer.open({
            title: ['添加菜单', 'font-size:16px'],
            type: 1,
            closeBtn: 2,
            skin: 'layui-layer-rim', //加上边框
            area: ['320px', '200px'], //宽高
            content: '<form id="menuform" method="post"> ' +
            '<input type="text" id="addmenuinput" name="addmenuinput" class="form-control addinput">' +
            '<span id="tips"></span></form>' +
            '<button class="btn addbtn" type="button" id="addmenubtnsure">添加</button> ' +
            '<button class="btn  addbtncal" id="addmenubtncal">取消</button>'
        })
        $('#addmenubtnsure').click(function () {
            if ($('#addmenuinput').val() == null || $('#addmenuinput').val().length < 1) {
                $('#tips').html("菜单名不能为空")
            } else {
                var formdata = $('#menuform').serialize();
                $.ajax({
                    type: "post",
                    data: formdata,
                    async: true,
                    url: "<?php echo Url('admin/index/addmenuresult'); ?>",
                    dataType: 'json',
                    success: function (response) {
                        // alert(JSON.stringify(response.error))
                        if (response == null || response == 'undefined') {
                            alert_fail('提示', '错误1');
                        } else {
                            if (JSON.stringify(response.error) == 'false') {
                                alert_success_url('提示', '添加成功', "<?php echo Url('admin/index/menuMg'); ?>");

                            } else {

                                alert_fail('提示', '添加失败');
                            }
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert_fail('提示', '错误-1');

                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }


                })
            }


        })
        $('#addmenubtncal').click(function () {
            layer.close(layer.index)
        })
    })
    //菜单删除
    $('div.menu ul>li>div span:nth-child(2)').click(function () {
        $a = $(this).parent().parent();
        $val = $a.children('#menuVal').text();
        // alert($val);
        // $('#menuli').val($val);
        // alert( $('#menuli').val());
        alert_ask('确定要删除吗?菜单下的文章将移至首页默认栏目下', function () {
            // var menuli = $('#menuliform').serialize();
            $.ajax({
                type: "post",
                data: {'data':JSON.stringify({menuId:$val})},
                dataType: "json",
                async: true,
                url: "<?php echo Url('admin/index/menuDel'); ?>",
                success: function (data) {
                    // alert(JSON.stringify(data))
                    if (data == null || data == 'undefined') {
                        alert_fail('提示', '错误1');
                    } else {
                        // alert(JSON.stringify(data.v).toString()=='1')
                        if (JSON.stringify(data.v) == "1") {
                            // alert(JSON.stringify(data.v))
                            alert_success_url('提示', '删除成功', "<?php echo Url('admin/index/menuMg'); ?>");

                        } else {
                            alert_fail('提示', '删除失败');
                        }
                    }
                },
                error: function () {
                    alert_fail('提示', '错误-1');
                }


            })
            // $a.css('display','none');
            // layer.closeAll();
        })
    })
    //添加类别
    $('.addtypebtn').click(function () {
        var menuid = $(this).parent().parent().children('#menuVal').text();
        var index = layer.open({
            title: ['添加类别(子菜单)', 'font-size:16px'],
            type: 1,
            closeBtn: 2,
            skin: 'layui-layer-rim', //加上边框
            area: ['320px', '200px'], //宽高
            content: '<form id="typeform" method="post"> ' +
            '<input type="text" id="addtypeinput" name="addtypeinput" class="form-control addinput">' +
            '<input type="text" id="type-menuid" name="menuid" style="display: none">' +
            '<span id="tips"></span></form>' +
            '<button class="btn addbtn" type="button" id="addtypebtnsure">添加</button> ' +
            '<button class="btn  addbtncal" id="addtypebtncal">取消</button>'
        })
        $('#addtypebtnsure').click(function () {
            if ($('#addtypeinput').val() == null || $('#addtypeinput').val().length < 1) {
                $('#tips').html("类别名不能为空")
            } else {
                // alert( menuid)
                $('#type-menuid').val(menuid);
                // alert( $('#type-menuid').val())
                var formdata = $('#typeform').serialize();
                $.ajax({
                    type: "post",
                    data: formdata,
                    async: true,
                    url: "<?php echo Url('admin/index/addtypeResult'); ?>",
                    dataType: 'json',
                    success: function (response) {
                        // alert(JSON.stringify(response.error))
                        if (response == null || response == 'undefined') {
                            alert_fail('提示', '错误1');
                        } else {
                            if (JSON.stringify(response.error) == 'false') {
                                alert_success_url('提示', '添加成功', "<?php echo Url('admin/index/menuMg'); ?>");

                            }else {
                                alert_fail('提示', '添加失败');
                            }
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert_fail('提示', '错误2');
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }


                })
            }


        })
        $('#addtypebtncal').click(function () {
            layer.close(layer.index)
        })
    })

    $('div.menu ul>li>ul>li>div span:nth-child(2)').click(function () {
        $a = $(this).parent().parent();
        $val = $a.children('#typeVal').text()
        // alert($val);
        // $('#typeli').val($val);
        // alert( $('#menuli').val());
        alert_ask('确定要删除吗?类别下的文章将移至首页默认栏目下。', function () {
            // var menuli = $('#typeliform').serialize();
            $.ajax({
                type: "post",
                data: {'data':JSON.stringify({typeId:$val})},
                dataType: "json",
                async: true,
                url: "<?php echo Url('admin/index/typeDel'); ?>",
                success: function (data) {
                    // alert(JSON.stringify(data))
                    if (data == null || data == 'undefined') {
                        alert_fail('提示', '错误1');
                    } else {
                        // alert(JSON.stringify(data.v).toString()=='1')
                        if (JSON.stringify(data.v) == "1") {
                            // alert(JSON.stringify(data.v))
                            alert_success_url('提示', '删除成功', "<?php echo Url('admin/index/menuMg'); ?>");

                        }else {
                            alert_fail('提示', '删除失败');
                        }
                    }
                }, error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert_fail('提示', '错误2');
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }



            })
            // $a.css('display','none');
            // layer.closeAll();
        })
    })
</script>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

