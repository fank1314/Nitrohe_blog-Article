<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:69:"D:\wamp\www\nitrohe_blog/application/admin\view\index\recycleBin.html";i:1538127531;s:67:"D:\wamp\www\nitrohe_blog\application\admin\view\baseView\index.html";i:1543641067;}*/ ?>
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css" media="all">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/admin.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/css/lc_switch.css">
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/jquery-ui/jquery-ui.css">
<!--<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">-->
<link rel="stylesheet" type="text/css" href="/nitrohe_blog/public/static/layui/css/layui.css">
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/jquery.form.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/common.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/js/lc_switch.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layer/layer.js">
</script>
<script type="text/javascript" src="/nitrohe_blog/public/static/layui/layui.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="/nitrohe_blog/public/static/tinymce/tinymce.min.js"></script>
<meta charset="UTF-8">
<div class="admin-top">
    <ul class="layui-nav nav-top">
        <li class="layui-nav-item">
            <a href="">后台管理系统</a>
        </li>
        <li class="layui-nav-item"></li>
        <li class="layui-nav-item  personinfo" lay-unselect="">
            <a href="javascript:;"><img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1500475355,713360726&fm=26&gp=0.jpg" class="layui-nav-img">Blog简窝</a>
            <dl class="layui-nav-child">
                <dd><a href="<?php echo Url('Admin/index/webConfig'); ?>">修改信息</a></dd>
                <dd><a href="<?php echo Url('Admin/login/loginout'); ?>">退出登录</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item homepage">
            <a href="<?php echo Url('Index/index/index'); ?>">网站首页</a>
        </li>
    </ul>
</div>
    <div class="leftsider">
        <ul class="layui-nav layui-nav-tree layui-inline " id="nav-left" style="margin-right: 10px;">
            <li class="layui-nav-item layui-nav-itemed " id="iconfontnav"><a><i class="iconfont">&#xe504;</i></a><a><i
                    class="iconfont">&#xe6e7;</i></a></li>
            <?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): if( count($menulist)==0 ) : echo "" ;else: foreach($menulist as $key=>$menulist): ?>
            <li class="layui-nav-item layui-nav-itemed menunav">
                <a href="javascript:;">
                    <i class="iconfont"><?php echo $menulist['icon']; ?></i>
                    <span class="nav-text"><?php echo $menulist['text']; ?></span>
                    &nbsp;</a>
                <dl class="layui-nav-child">
                    <?php if(is_array($menulist['submenu']) || $menulist['submenu'] instanceof \think\Collection || $menulist['submenu'] instanceof \think\Paginator): if( count($menulist['submenu'])==0 ) : echo "" ;else: foreach($menulist['submenu'] as $key=>$submenu): ?>
                    <dd <?php if($submenu['name'] == $cursubmenu): ?> class="ddactive"
                        <?php endif; ?>>
                    <a href="<?php echo $submenu['url']; ?>">
                        <i class="iconfont"><?php echo $submenu['icon']; ?></i>
                        <span class="nav-text"> <?php echo $submenu['text']; ?></span>
                        <?php if(($notreadcm>0)): if(($submenu['name']=='dynamic')): ?>
                            <span class="dynamic-nav"><?php echo $notreadcm; ?></span>
                            <?php endif; endif; ?>
                    </a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </ul>

    </div>
<div class="content-parent">
    <div></div>
    <div class="content">
        
<title>文章回收站</title>
<div class="recycleBin">
    <p>文章回收站</p>
    <div>
        <span>
            <input style="position: relative;top:5px;" type="checkbox" id="sel-art">
            <select class="selectpicker" id="art-op-sel" title="批量操作">
             <option value="1">删除</option>
             <option value="2">恢复至草稿</option>
            </select>
            <button class="btn" id="art-op">应用</button>
          </span>
    </div>
    <div class="art-list">
        <table class="table table-hover table-artlist">
            <tr>
                <th>标题</th>
                <th>作者</th>
                <th>分类</th>
                <th class="art-date">删除日期<span>
                    <a style="color: #5bc0de"><i class="iconfont">&#xe655;</i></a>
                </span></th>
                <th>操作</th>
                <th style="display: none"></th>
            </tr>

            <?php if(is_array($article) || $article instanceof \think\Collection || $article instanceof \think\Paginator): if( count($article)==0 ) : echo "" ;else: foreach($article as $key=>$article): ?>
            <tr>
                <td class="td-title"><?php echo $article['article_title']; ?></td>
                <td class="td-author"><?php echo $article['article_author']; ?></td>
                <td><?php echo $article['article_type']['types_content']; ?></td>
                <td><?php echo $article['article_pushdate']; ?></td>
                <td class="table-btn">
                    <button class="btn restore">恢复至草稿</button>
                    <button class="btn  del">删除</button>
                </td>
                <td style="display: none" class="td-artid"><?php echo $article['article_id']; ?></td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <div> <?php echo $page; ?></div>
    </div>
</div>
<script>
    $('#sel-art').click(function () {
        if ($(this).is(':checked')) {
            $('table tr:first-child th:first-child').before('<th><input type="checkbox" class="sel-all"><span>全选</span></th>')
            $('table tr').each(function (index, ele) {
                var artid = $(this).find('td.td-artid').text();
                $(this).find('td:first-child').before(' <td><input type="checkbox" class="sel-art-check" value=' + artid + '> </td> ')
            });
            $('table tr>td:first-child').css('width', '8%');
            $('.art-list').on('click','.sel-all',function () {
                if ($(this).is(':checked')){
                    $('.sel-art-check').prop('checked','checked');
                    $('table tr:first-child th:first-child span').html('取消全选');
                }else{
                    $('.sel-art-check').removeAttr('checked');
                    $('table tr:first-child th:first-child span').html('全选');

                }
            });
        } else {
            $('table tr:first-child th:first-child').remove()
            $('table tr').each(function (index, ele) {
                $(this).find('td:first-child').remove()
            })
        }
    });
    $('th.art-date>span').click(function () {
        var Request=new Object();
        Request=GetRequest();
        if (Request['dateOrder']!=2){
            window.location.href= "<?php echo Url('admin/index/myArticle'); ?>?dateOrder="+2;
        }else {
            window.location.href= "<?php echo Url('admin/index/myArticle'); ?>?dateOrder="+1;

        }
    });
    $('#art-op').click(function () {
        var selval = $('#art-op-sel').val();
        // console.log(selval)
        var artids = new Array();
        if (selval == undefined || selval == '') {
            alert_fail('提示', '未选择操作')
        } else {
            $('.sel-art-check:checked').each(function (index, ele) {
                // console.log($(this).val())
                artids[index] = $(this).val();
            });
            console.log(artids)
            if (artids.length === 0) {
                alert_fail('提示', '你未选择文章')
            } else {
                if (selval == 1) {
                    alert_ask('确定要永久删除此文章！(此操作不可恢复)?',function () {
                        selOp("<?php echo Url('admin/index/delArt'); ?>", artids);

                    });
                } else if (selval == 2) {
                    selOp("<?php echo Url('admin/index/restore'); ?>", artids)
                }


            }
        }
    });

    function ajaxs(data, url, succ) {
        var re = 0;
        $.ajax({
            type: 'post',
            data: data,
            dataType: 'json',
            url: url,
            success: function (data) {
                console.log(data)
                if (JSON.stringify(data) == '1') {
                    succ();
                } else {
                    alert_fail('提示', '操作失败')

                }
            }
            , error: function () {
                alert_fail('提示', '未知错误')
            }

        })
    }

    function selOp(url, artids) {
        for (var i = 0; i < artids.length; i++) {
            ajaxs({'data': JSON.stringify({artid: artids[i]})}, url, function () {
                alert_success('提示', '操作成功')
            })
        }
        setTimeout(function () {
            $('.sel-art-check:checked').each(function (index, ele) {
                // console.log($(this).val())
                $(this).parent().parent().remove()
            })
        }, 2000)
    }
    $('.restore').click(function () {
        var artid = $(this).parent().next().text();
        var curart = $(this).parent().parent();
        var re = ajaxs({'data': JSON.stringify({artid: artid})}, "<?php echo Url('admin/index/restore'); ?>", function () {
            setTimeout(function () {
                curart.remove();
            },2200);
            alert_success('提示', '操作成功')

        })
    });
    $('.del').click(function () {
        var artid = $(this).parent().next().text();
        var curart = $(this).parent().parent();
        alert_ask('确定要永久删除此文章！(此操作不可恢复)?', function () {
            var re = ajaxs({'data': JSON.stringify({artid: artid})}, "<?php echo Url('admin/index/delArt'); ?>", function () {
                setTimeout(function () {
                    curart.remove();
                },2200);
                alert_success('提示', '操作成功')

            })


        })
    });
</script>

    </div>

</div>

<script>
    var iconfontnav = document.getElementById('iconfontnav');
    var navleft = document.getElementById('nav-left');
    var content = document.getElementsByClassName("content");
    var status = 1;
   var docWidth=$(document).width();
   // $('.content').css('width',(docWidth-200)+'px');
   // console.log(docWidth);
    // $('.admin-left-main').css('width',docWidth+'px')
    iconfontnav.onclick = function () {
        // alert(status);
        var navtext = document.getElementsByClassName('nav-text');
        var iconfontnavchild = iconfontnav.childNodes;
        if (status == 1) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "none";
                // alert(navtext[i].innerHTML)
            }
            iconfontnav.childNodes[0].style.display = 'none';
            iconfontnav.childNodes[1].style.display = 'block';
            // alert(iconfontnavchild.length)
            navleft.classList.add('nav-sider');
            // $('.content').css('width','90%')
            $('.leftsider').css('width','70px');
            $('.content-parent > div:first-child').css('width','70px');
            status = 0;
        }
        else if (status == 0) {
            for (var i = 0; i < navtext.length; i++) {
                // navtext[i].parentNode.removeChild(navtext[i]);
                navtext[i].style.display = "inline-block";
                // i--;
                // alert(navtext[i].innerHTML)
                $('.leftsider').css('width','200px')
                $('.content-parent > div:first-child').css('width','200px');
            }
            iconfontnav.childNodes[1].style.display = 'none'
            iconfontnav.childNodes[0].style.display = 'block';
            navleft.classList.remove('nav-sider');
            status = 1;
        }
    };


    layui.use('element', function () {
        var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块

        //监听导航点击
        element.on('nav(demo)', function (elem) {
            //console.log(elem)
            layer.msg(elem.text());
        });
    });
</script>

<script>

</script>

